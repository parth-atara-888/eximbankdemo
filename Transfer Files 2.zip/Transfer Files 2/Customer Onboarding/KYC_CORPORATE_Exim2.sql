
/*%Let application_id =  &a.;
%Let temp_name =  &b.;
%Let temp_country =  &C.;
%Let temp_doi =  &d.;
%let accountant_name = &e.;
%let accountant_country = &g.;
%let accountant_dob = &f.;*/


%Let country = ;
%let temp_case_type=CS;

/* Step 1: Extract the fileContent from the payload JSON and save it*/
filename payload filesrvc "&_WEBIN_FILEURI";
%put %sysfunc(jsonpp(payload,log));

data _null_;
    rc = jsonpp('payload', 'log');
run;

/* CHECK THE LIBNAME STATEMENT */
libname fdhdata postgres server='sasserver.demo.sas.com' port=5432  user='dbmsowner' password='Orion123' database=SharedServices schema = fdhdata;


/* STEP 2: Extract tables from Input JSON */
libname myjson2 JSON fileref = payload;

data tempresponse;
set MYJSON2.NAMESCREENINGRESPONSE;
run;

data tempindresponse;
set MYJSON3.data;
run;

data tempindscorecard;
set MYJSON3.DATA_SCORELIST;
run;

data kyc_corporate;
set MYJSON3.applicationDetails;
run;


/* chief accountant's nationality(country in VI entity) is mapped to stakeholder's nationality */

/*proc sql;
select strip(kyc_businessnature),strip(kyc_legalstatus),strip(kyc_businesstenure),strip(kyc_annualturnover),strip(kyc_bankrelationship),
strip(chief_accountant_country),strip(kyc_annualtxnvalue),strip(kyc_profession),strip(kyc_pep)
 into: businessnature,:legalstatus,:businesstenure,:annualturnover,:bankrelationship,:stakeholdernationality,:annualtxnvalue,:profession,:pep
from work.kyc_corporate;
quit;*/


proc sql;
select strip(customerID),strip(Name),strip(dob),strip(nationalityCountryName),strip(customer_type),strip(business_nature),strip(legal_status),
strip(business_tenure),strip(shareholder_nationality),strip(annual_turnover),strip(bank_relationship),
strip(stakeholder_profession),strip(annual_txn_value),strip(country_of_incorporation),strip(date_of_incorporation),strip(shareholder_pep_status)
 into: application_id,:Name,:chief_accountant_dob,:nationality,:customer_type,:kyc_businessnature,:kyc_legalstatus,:kyc_businesstenure,:kyc_stakeholdernationality
,:kyc_annualturnover,:kyc_bankrelationship,:kyc_profession,:kyc_annualtxnvalue,:chief_accountant_country,:DOI,:kyc_pep
from work.kyc_corporate;
quit;


/* ADD ANY LOOKUP FOR ANY VALUE IF NEEDED */

/* %let responsecheck = 1; */
%macro checkresponse();

proc sql;
select compress(put(min(ordinal_nameScreeningResponse),best.)) into: responsecheck
from tempresponse;
quit;

/* options notes; */
%put responsecheck: &responsecheck.;


/*========== Call effiya CDD here since there is no match against watchlist=========*/
/*  */
%let application_id = %sysfunc(strip(&application_id.));
%let Name = %sysfunc(strip(&Name.));
%let chief_accountant_dob = %sysfunc(strip(&chief_accountant_dob.));
%let nationality = %sysfunc(strip(&nationality.));
%let customer_type = %sysfunc(strip(&customer_type.));
%let kyc_businessnature = %sysfunc(strip(&kyc_businessnature.));
%let kyc_legalstatus = %sysfunc(strip(&kyc_legalstatus.));
%let kyc_businesstenure = %sysfunc(strip(&kyc_businesstenure.));
%let kyc_stakeholdernationality = %sysfunc(strip(&kyc_stakeholdernationality.));
%let kyc_annualturnover = %sysfunc(strip(&kyc_annualturnover.));
%let kyc_bankrelationship = %sysfunc(strip(&kyc_bankrelationship.));
%let kyc_profession = %sysfunc(strip(&kyc_profession.));
%let kyc_annualtxnvalue = %sysfunc(strip(&kyc_annualtxnvalue.));
%let chief_accountant_country = %sysfunc(strip(&chief_accountant_country.));
%let DOI = %sysfunc(strip(&DOI.));
%let kyc_pep = %sysfunc(strip(&kyc_pep.));


filename indrsp temp;
filename indrspo temp;
filename indreq temp;

data _null_;
file indreq;
length request_body $2000.;
put %unquote(%nrbquote('
{
	"requestID": "&application_id.",
	"customerID": "&application_id.",
	"customer_type": "corporate",
	"business_nature":"&businessnature.",
	"legal_status":"&legalstatus.",
	"business_tenure":"&businesstenure.",
	"shareholder_nationality" :"&stakeholdernationality.",
	"annual_turnover":"&annualturnover.",
	"bank_relationship":"&bankrelationship.",
	"stakeholder_profession":"&profession.",
	"annual_txn_value":"&annualtxnvalue.",
	"country_of_incorporation": "&temp_country.",
	"shareholder_pep_status":"&pep."
}
'));
run;


 data _null_;
	infile indreq;
	input;
	put _INFILE_;
run;
  
options set=SSLREQCERT="allow";
proc http in=indreq
 out = indrsp
 headerout = indrspo
url = 'https://demo.effiya.com/kyc/api/cdd-scoring'
method = 'post'
ct = 'application/json';
run;

libname myjson3 JSON fileref = indrsp;

data _null_;
	infile indrsp;
	input;
	put _INFILE_;
run;

data tempindresponse;
set MYJSON3.data;
run;

data tempindscorecard;
set MYJSON3.DATA_SCORELIST;
run;

proc sql;
create table allresponse as 
select 
A.requestId,
A.customerId,
A.customer_type,
A.riskBand,
A.riskScore,
B.variableName,
B.variableValue,
B.score,
B.weight,
round(B.wt_score,0.01) as wt_score,
B.ordinal_scoreList
FROM work.tempindresponse A 
JOIN work.tempindscorecard B
on A.ordinal_data = B.ordinal_data;
quit;

%let datetime=%sysfunc(datetime(),datetime24.);
%let dt=%sysfunc(compress(&datetime,":"));
%put &dt.;

data work.allresponse;
length assessment_id $100.;
format created_dttm datetime20.;
set work.allresponse;
created_dttm = datetime();
assessment_id = catx('_',requestid,ordinal_scoreList,"&dt.");
run;

proc sql;
connect to postgres as x1 (server='sasserver.demo.sas.com' port=5432 user='dbmsowner' password='Orion123' database=amlcore);
execute (

     delete from  core."scorelist"
     where cast("requestId" as integer) = &application_id.

) by x1;

disconnect from x1;

quit;


proc append base = WSHLA.scorelist data = work.allresponse force;
run;

/* ======== Update the risk category, score and assessment date in onboarding customer entity=====*/

proc sql;
select cat("'",strip(riskband),"'") ,strip(riskscore) 
 into: riskcat ,:riskscore trimmed
from WORK.TEMPINDRESPONSE;
quit;

%put &riskcat. &riskscore.;

/* Step 1: Convert riskscore to numeric with precision 4 and scale 2 in SAS */

%let riskscore_num = %sysfunc(putn(%sysevalf(&riskscore.), 4.2));
/* Step 2: Use a pass-through SQL query to update the table */

/* %let assessment_date = date(); */



proc sql;

connect to postgres as x1 (server='sasserver.demo.sas.com' port=5432 user='dbmsowner' password='Orion123' database=SharedServices);

execute (

    update fdhdata."Onboarding_customer"

    set onboarding_risk_category = &riskcat.,

        onboarding_risk_score = &riskscore_num.
/*also add date 	 */
    where cast(onboarding_customer_id as integer) = &application_id.

) by x1;

disconnect from x1;

quit;


libname fdhdata postgres server='sasserver.demo.sas.com' port=5432  user='dbmsowner' password='Orion123' database=SharedServices schema = fdhdata;


proc sql;
delete from fdhdata.cddscorelistdata 
where requestid="&application_id.";
quit;


proc sql;
INSERT INTO fdhdata.cddscorelistdata 
select * from wshla.scorelist where requestid="&application_id.";
quit;

proc sql;
connect to postgres as x1 (server='sasserver.demo.sas.com' port=5432  user='dbmsowner' password='Orion123' database=SharedServices);
EXECUTE(insert into fdhdata.cdd_scorelist_x_onboardingcust
(auto_generated_sk,assessment_id,created_at_dttm,created_by_user_id,onboarding_customer_id,last_updated_at_dttm,last_updated_by_user_id,version)
select 
A.assessment_id || A.ordinal_scorelist ,
A.assessment_id,current_timestamp,current_user,b.onboarding_customer_id,current_timestamp,current_user,1
from fdhdata."cddscorelistdata" a join fdhdata."Onboarding_customer" b on a.requestid=b.onboarding_customer_id 
where CAST(a.requestid as integer)=&application_id. and CAST(b.onboarding_customer_id as integer)=&application_id.
)
by x1;
quit;

/*========Checking for Risk category to take decision for case creation===============*/

%if %SYSEVALF(&riskcat. ='High' ) or %SYSEVALF(&responsecheck. =2) %then %do;



filename rsp temp;
filename rsp_o temp;
filename req temp;


data _null_;
	file req;
	length request_body $2000.;
	put %unquote(%nrbquote('{"objectTypeName":"screening_case","objectTypeId":"113000","fieldValues":{"application_id":"&application_id.","name":"&temp_name.","country":"&country.","dob":"&temp_doi.","screening_case_type":"&temp_case_type."},"comments":[]}'));
run;


options noquotelenmax;
options set=SSLREQCERT="allow";

proc http in=req
		out=rsp
		headerout=rsp_o
		url="https://sasserver.demo.sas.com/svi-datahub/documents"
		method="POST"
		OAUTH_BEARER=SAS_SERVICES
		ct="application/json"
clear_cache;
	run;
	
	/*Displays the headers from the API*/
	data _null_;
		infile rsp_o;
		input;
		put _INFILE_;
	run;

	/*Displays the response from the API*/
	data _null_;
		infile rsp;
		input;
		put _INFILE_;
	run;



proc sql;
delete from wshla.Matched_records where uniqueid="&application_id.";
quit;

%let datetime=%sysfunc(datetime(),datetime24.);
%let dt=%sysfunc(compress(&datetime,":"));
%put &dt.;

data tempresponse;
length match_id $100.;
format created_dttm datetime20.;
set tempresponse;
created_dttm = datetime();
match_id = catx('_',uniqueId,entityWatchListKey,"&dt.");
run;

proc append base = wshla.Matched_records data = tempresponse force;
run;


libname fdhdata postgres server='sasserver.demo.sas.com' port=5432  user='dbmsowner' password='Orion123' database=SharedServices schema = fdhdata;

proc sql;
connect to postgres as x1 (server='sasserver.demo.sas.com' port=5432  user='dbmsowner' password='Orion123' database=SharedServices);
select case_id into: temp_case_id from connection to x1
(select max(screening_case_id) "case_id" from fdhdata.screening_case where cast(application_id as integer)=&application_id.);	
 disconnect from x1;
quit;




proc sql;
delete from fdhdata.testscreening where uniqueid="&application_id.";
quit;

proc sql;
INSERT INTO fdhdata.testscreening 
select * from wshla.Matched_records where uniqueid="&application_id.";
quit;


proc sql;
connect to postgres as x1 (server='sasserver.demo.sas.com' port=5432  user='dbmsowner' password='Orion123' database=SharedServices);
EXECUTE(insert into fdhdata."Screening_x_matched"
(auto_generated_sk,screening_case_id,created_at_dttm,created_by_user_id,match_id,last_updated_at_dttm,last_updated_by_user_id,version)
select 
A.match_id || A.ordinal_nameScreeningResponse ,
b.screening_case_id,current_timestamp,current_user,a.match_id,current_timestamp,current_user,1
from fdhdata."testscreening" a join fdhdata."screening_case" b on a.uniqueid=b.application_id 
where CAST(a.uniqueid as integer)=&application_id. and CAST(b.screening_case_id as integer)=&temp_case_id.
)
by x1;
quit;

proc sql;
connect to postgres as x1 (server='sasserver.demo.sas.com' port=5432  user='dbmsowner' password='Orion123' database=SharedServices);
EXECUTE(
insert into fdhdata."Screening_case_x_application" 
(auto_generated_sk,screening_case_id,created_at_dttm,created_by_user_id,onboarding_customer_id,last_updated_at_dttm,last_updated_by_user_id,version)
values
(concat(&application_id.,&temp_case_id.),&temp_case_id.,current_timestamp,current_user,&application_id.,current_timestamp,current_user,1)
) by x1;
quit;

proc sql;
connect to postgres as x1 (server='sasserver.demo.sas.com' port=5432  user='dbmsowner' password='Orion123' database=amlcore);
EXECUTE(
insert into core."Matched_records_x_watchlist"
(match_id,entity_watchlist_key)
select 
A.match_id, A."entityWatchListKey"
from core."Matched_records" A  
where CAST(a."uniqueId" as integer)=&application_id.
) by x1;
quit;

proc sql;
connect to postgres as x1 (server='sasserver.demo.sas.com' port=5432  user='dbmsowner' password='Orion123' database=SharedServices);
execute
(update fdhdata."Onboarding_customer" set application_status='On hold' where cast(onboarding_customer_id as integer)=&application_id.
) by x1;
quit;

%let _status_message= The customer onboarding for Application ID = "&application_id." has been placed on hold for further review. Kindly check Case number = "&temp_case_id."  under My Screening Cases tab;

%end;
%else %do;
%let _status_message= Application ID = "&application_id." has been approved for onboarding;
%end;


%macro reindex;
	/*Defining temporary files*/
	filename rsp temp;

	/*Stores response received from the API*/
	filename rsp_o temp;

	/*Stores the headers for API call*/
	filename jsoncnt temp;

	/*Stores the request response for API call*/
	%let server=https://sasserver.demo.sas.com;
	
	/*Defining the server*/
	/*This block of code defines the JSON request reponse for API call and stores it in the json_content file*/


data _null_;
		file jsoncnt;
		length json_content $2000.;
		put %unquote(%nrbquote('{"parameters": {"type": "SEARCH_INDEX_LOADER"},"tasks":[{"parameters": {"type":"LOAD_DOCUMENT","name":"screening_case"}},{"parameters": {"type":"LOAD_DOCUMENT","name":"Matched_records"}},{"parameters": {"type":"LOAD_DOCUMENT","name":"watchlist_details"}},{"parameters": {"type":"LOAD_DOCUMENT","name":"cdd_scorelist"}},{"parameters": {"type":"LOAD_DOCUMENT","name":"Onboarding_customer"}}]}'));
	run;

data _null_;
		infile jsoncnt;
		input;
		put _INFILE_;
	run;

	options noquotelenmax;
options set=SSLREQCERT="allow";
	/*block end*/
	/*proc http is used to connect to the API endpoint. Here we are also defining the headers and storing it in rsp_o file*/
	proc http in=jsoncnt
		out=rsp
		headerout=rsp_o
		url="https://sasserver.demo.sas.com/svi-datahub/admin/asyncJobs?new"
		method="POST"
		OAUTH_BEARER=SAS_SERVICES
		ct="application/json"
        clear_cache;
/* 		headers 'Authorization'="Bearer &ACCESS_TOKEN."; */
	run;

	/*block ends*/
	options notes;

	/*Writes below statement in SAS logs*/
	%put NOTE: Response header from the service is as follows :;
	options nonotes;

	/*Disales writing in SAS logs*/
	/*Displays the headers from the API*/
	data _null_;
		infile rsp_o;
		input;
		put _INFILE_;
	run;

	/*block ends*/
	options notes;

	/*Specifies that SAS write notes to the SAS logs*/
	%put NOTE: Response file from the service is as follows :;
	options nonotes;

	/*Specifies that SAS not write notes to the SAS logs*/
	/*Displays the response from the API*/
	data _null_;
		infile rsp;
		input;
		put _INFILE_;
	run;
	
%mend;

/*Function ends*/
%reindex;


%mend;

%checkresponse;