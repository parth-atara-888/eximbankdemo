DATA tm_transactions;
  LENGTH
    transaction_dttm          8
    transaction_reference_number $100
    transaction_cdi_code      $4
    currency_code             $8
    currency_amount           8
    primary_medium_desc       $120
    status_desc               $100
    secondary_account_number  $120
    account_number            $200
    transaction_description   $200
    remitter_ext_party_number $400
    ext_account_number        $200
    ext_party_type_desc       $100
    ext_party_full_name       $200
    ext_address_line_1_text   $300
    ext_address_line_2_text   $300
    ext_city_name             $200
    ext_state_name            $200
    country_code              $50
    party_number              $200
    party_type_desc           $50
    party_name                $300
    annual_income_amount      8
    annual_turnover           8
    address_line_1_text       $300
    address_line_2_text       $300
    city_name                 $200
    state_name                $200
    account_name              $200
    opened_by_party_number    $100
    opened_by_party_name      $200
  ;

  FORMAT transaction_dttm DATETIME27.6;
  FORMAT currency_amount 20.5;
RUN;
