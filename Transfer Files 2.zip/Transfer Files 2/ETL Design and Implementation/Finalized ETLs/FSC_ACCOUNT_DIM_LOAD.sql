/*Account Dim Load Job*/



PROC SORT DATA=WORK.tm_transactions(KEEP=account_number account_name opened_by_party_number opened_by_party_name
                               WHERE=(account_number is not null))
          OUT=account_dim_valid NODUPKEY;
  BY account_number;
RUN;

%LET start_time = %SYSFUNC(DATETIME(), DATETIME.); /* Record job start timestamp */

/* Count staging records for audit logging */
PROC SQL;
    SELECT COUNT(*) INTO: valid_count
    FROM WORK.account_dim_valid;
QUIT;

/*------------------------------------------
Get the Maximum Key Data
 *------------------------------------------*/
/* Generate the maximum key */
		%let etls_maxkey = -1;
%put etls_maxkey : &etls_maxkey.;

proc sql noprint;
	select compress(put(max(ACCOUNT_KEY), best32.)) into :etls_maxkey from 
		WSHLA.FSC_ACCOUNT_DIM;
quit;

%put etls_maxkey : &etls_maxkey.;


/* Add digest and SCD fields to staging data */
DATA account_dim_stg;
    SET WORK.account_dim_valid; /* Load staging data */

    /* Assign change begin date */
    change_begin_date = DATETIME();
    change_end_date    = dhms('01Jun5999'd, 0, 0, 0);
    change_current_ind = 'Y'; /* Active flag */

    /* Assign surrogate key */
    ACCOUNT_KEY = &etls_maxkey + _N_; /* Ensure &etls_maxkey is defined as numeric */
	version = 1;

    FORMAT change_begin_date DATETIME27.6;
    FORMAT change_end_date DATETIME27.6;
    FORMAT change_current_ind $2.;
    FORMAT ACCOUNT_KEY Z13.; 
	FORMAT version Z2.; 
RUN;



proc sql;
update WSHLA.FSC_ACCOUNT_DIM
set CHANGE_CURRENT_IND = 'N',
CHANGE_END_DATE = DATETIME()
where 
ACCOUNT_NUMBER in (select distinct ACCOUNT_NUMBER from account_dim_stg);
quit;

proc append base=WSHLA.FSC_ACCOUNT_DIM data=account_dim_stg force;
run;

