data tm_transactions;
  length
    transaction_dttm 8
    transaction_reference_number $20
    transaction_cdi_code $1
    currency_code $3
    currency_amount 8
    primary_medium_desc $30
    status_desc $20
    secondary_account_number $30
    account_number $30
    transaction_description $100
    remitter_ext_party_number $30
    ext_account_number $30
    ext_party_type_desc $20
    ext_party_full_name $100
    ext_address_line_1_text $100
    ext_address_line_2_text $100
    ext_city_name $50
    ext_state_name $50
    country_code $2
    party_number $20
    party_type_desc $20
    party_name $100
    annual_income_amount 8
    annual_turnover 8
    address_line_1_text $100
    address_line_2_text $100
    city_name $50
    state_name $50
    account_name $100
    opened_by_party_number $20
    opened_by_party_name $100
  ;

  format transaction_dttm datetime20.;
  format currency_amount 20.2;

  /* Party 1: Yogeshwar, 5 Transactions */
  do i = 1 to 5;
    transaction_dttm = dhms('01JUN2024'd + i - 1, 9+i, 0, 0);
    transaction_reference_number = cats('TXN', put(i, z3.));
    transaction_cdi_code = ifc(mod(i,2)=0, 'D', 'C'); /* Alternate Credit/Debit */
    currency_code = 'INR';
    currency_amount = 1000 + i*500;
    primary_medium_desc = scan('ATM Cash Branch Transfer Wire', i);
    status_desc = 'Completed';
    account_number = 'IN-001-YOG-1001';
    secondary_account_number = ifc(i=4, 'IN-001-YOG-2002', '');
    transaction_description = scan('Cash Withdrawal Salary Deposit Internal Transfer to checking Wire to vendor', i);
    remitter_ext_party_number = cats('EXT-YOG-', i);
    ext_account_number = cats('EXTACC-YOG-', i);
    ext_party_type_desc = 'INDIVIDUAL';
    ext_party_full_name = 'Ravi Kumar';
    ext_address_line_1_text = '45, Central Market Road';
    ext_address_line_2_text = 'Near Metro Station';
    ext_city_name = 'Delhi';
    ext_state_name = 'Delhi';
    country_code = 'IN';
    party_number = 'P001';
    party_type_desc = 'INDIVIDUAL';
    party_name = 'Oscar Piastri';
    annual_income_amount = 2500000;
    annual_turnover = 0;
    address_line_1_text = '22, Green Park';
    address_line_2_text = 'South Extension';
    city_name = 'Delhi';
    state_name = 'Delhi';
    account_name = 'Oscar Piastri';
    opened_by_party_number = 'P001';
    opened_by_party_name = 'Oscar Piastri';
    output;
  end;

  /* Party 2: Aisha, 3 Transactions */
  do i = 1 to 3;
    transaction_dttm = dhms('06JUN2024'd + i - 1, 10+i, 15, 0);
    transaction_reference_number = cats('TXN', put(i+5, z3.));
    transaction_cdi_code = ifc(i=2, 'E', 'D'); /* Mix of event and debit */
    currency_code = 'INR';
    currency_amount = 2000 + i*750;
    primary_medium_desc = scan('Branch UPI ATM', i);
    status_desc = 'Completed';
    account_number = 'IN-002-AIS-2001';
    secondary_account_number = '';
    transaction_description = scan('Loan EMI Payment Bill Payment ATM Withdrawal', i);
    remitter_ext_party_number = cats('EXT-AIS-', i);
    ext_account_number = cats('EXTACC-AIS-', i);
    ext_party_type_desc = 'ORGANIZATION';
    ext_party_full_name = 'Reliance Energy';
    ext_address_line_1_text = 'Corporate Tower A';
    ext_address_line_2_text = 'Bandra Kurla Complex';
    ext_city_name = 'Mumbai';
    ext_state_name = 'Maharashtra';
    country_code = 'IN';
    party_number = 'P002';
    party_type_desc = 'INDIVIDUAL';
    party_name = 'Max Verstappen';
    annual_income_amount = 1800000;
    annual_turnover = 0;
    address_line_1_text = '17, Carter Road';
    address_line_2_text = 'Bandra West';
    city_name = 'Mumbai';
    state_name = 'Maharashtra';
    account_name = 'Max Verstappen';
    opened_by_party_number = 'P002';
    opened_by_party_name = 'Max Verstappen';
    output;
  end;

  /* Party 3: John, 2 Transactions */
  do i = 1 to 2;
    transaction_dttm = dhms('10JUN2024'd + i - 1, 13+i, 30, 0);
    transaction_reference_number = cats('TXN', put(i+8, z3.));
    transaction_cdi_code = 'C';
    currency_code = 'USD';
    currency_amount = 3000 + i*100;
    primary_medium_desc = scan('Wire Cash', i);
    status_desc = 'Completed';
    account_number = 'US-003-JOH-3001';
    secondary_account_number = '';
    transaction_description = scan('Wire Transfer from employer Cash Deposit', i);
    remitter_ext_party_number = cats('EXT-JOH-', i);
    ext_account_number = cats('EXTACC-JOH-', i);
    ext_party_type_desc = 'ORGANIZATION';
    ext_party_full_name = 'ABC Corp';
    ext_address_line_1_text = '100 Wall Street';
    ext_address_line_2_text = 'Suite 500';
    ext_city_name = 'New York';
    ext_state_name = 'NY';
    country_code = 'US';
    party_number = 'P003';
    party_type_desc = 'INDIVIDUAL';
    party_name = 'John Doe';
    annual_income_amount = 3200000;
    annual_turnover = 0;
    address_line_1_text = '12 Park Avenue';
    address_line_2_text = 'Manhattan';
    city_name = 'New York';
    state_name = 'NY';
    account_name = 'John Doe';
    opened_by_party_number = 'P003';
    opened_by_party_name = 'John Doe';
    output;
  end;

  /* Party 4: Priya, 1 Transaction */
  transaction_dttm = dhms('12JUN2024'd, 14, 0, 0);
  transaction_reference_number = 'TXN011';
  transaction_cdi_code = 'D';
  currency_code = 'INR';
  currency_amount = 5000;
  primary_medium_desc = 'NEFT';
  status_desc = 'Completed';
  account_number = 'IN-004-PRI-4001';
  secondary_account_number = '';
  transaction_description = 'NEFT to vendor';
  remitter_ext_party_number = 'EXT-PRI-1';
  ext_account_number = 'EXTACC-PRI-1';
  ext_party_type_desc = 'INDIVIDUAL';
  ext_party_full_name = 'Vendor Priya';
  ext_address_line_1_text = '67 MG Road';
  ext_address_line_2_text = 'Block B';
  ext_city_name = 'Chennai';
  ext_state_name = 'Tamil Nadu';
  country_code = 'IN';
  party_number = 'P004';
  party_type_desc = 'INDIVIDUAL';
  party_name = 'Kimi Andrea';
  annual_income_amount = 1400000;
  annual_turnover = 0;
  address_line_1_text = '32 Anna Nagar';
  address_line_2_text = 'West Extension';
  city_name = 'Chennai';
  state_name = 'Tamil Nadu';
  account_name = 'Kimi Andrea';
  opened_by_party_number = 'P004';
  opened_by_party_name = 'Kimi Andrea';
  output;

run;
