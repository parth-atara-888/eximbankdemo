proc contents data = WSHLA.FSC_BRANCH_DIM;
quit;


proc sql;
    insert into WSHLA.FSC_BRANCH_DIM (
        branch_key, branch_type_desc, branch_number, branch_name, branch_status_desc, 
        street_address_1, street_address_2, street_city_name, 
        street_state_code, street_state_name, 
        street_country_code, street_country_name, phone_number,
        change_begin_date, change_end_date, change_current_ind, version
    )
    values (
        897568, 'BRANCH', '897568', 'EXIMBANK BRANCH 1', 'ACTIVE', 
        'FLOOR 8, VINCOM, SUITE L8-01-11+16, 72', 'LE THANH TON STREET', 'VIETNAM', 
        'VN', 'VN', 
        'VN', 'VIETNAM', '1900 6655', 
        %sysfunc(datetime()), %sysfunc(dhms('01Jun5999'd, 0, 0, 0)), 'Y', 1
    );
quit;

