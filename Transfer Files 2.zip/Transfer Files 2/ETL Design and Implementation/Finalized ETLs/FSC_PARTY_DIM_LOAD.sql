/*Party Dim Load Job*/


/* Step 1: FSC_PARTY_DIM – Deduplicate by party_number */
PROC SORT DATA= tm_transactions(KEEP=party_number party_type_desc party_name annual_income_amount
                               annual_turnover address_line_1_text address_line_2_text
                               city_name state_name country_code
                               WHERE=(party_number is not null))
          OUT=party_dim_valid NODUPKEY;
  BY party_number;
RUN;

%LET start_time = %SYSFUNC(DATETIME(), DATETIME.); /* Record job start timestamp */

/* Count staging records for audit logging */
PROC SQL;
    SELECT COUNT(*) INTO: valid_count
    FROM WORK.party_dim_valid;
QUIT;


/*------------------------------------------
Get the Maximum Key Data
 *------------------------------------------*/
/* Generate the maximum key */
		%let etls_maxkey = -1;
%put etls_maxkey : &etls_maxkey.;

proc sql noprint;
	select compress(put(max(PARTY_KEY), best32.)) into :etls_maxkey from 
		WSHLA.FSC_PARTY_DIM;
quit;

%put etls_maxkey : &etls_maxkey.;


/* Add digest and SCD fields to staging data */
DATA party_dim_stg;
    SET WORK.party_dim_valid; /* Load staging data */

    /* Assign change begin date */
    change_begin_date = DATETIME();
    change_end_date    = dhms('01Jun5999'd, 0, 0, 0);
    change_current_ind = 'Y'; /* Active flag */

    /* Assign surrogate key */
    PARTY_KEY = &etls_maxkey + _N_; /* Ensure &etls_maxkey is defined as numeric */
	version = 1;

    FORMAT change_begin_date DATETIME27.6;
    FORMAT change_end_date DATETIME27.6;
    FORMAT change_current_ind $2.;
    FORMAT PARTY_KEY Z13.; 
	FORMAT version Z2.; 
RUN;



proc sql;
update WSHLA.FSC_PARTY_DIM
set CHANGE_CURRENT_IND = 'N',
CHANGE_END_DATE = DATETIME()
where 
PARTY_NUMBER in (select distinct PARTY_NUMBER from party_dim_stg);
quit;

proc append base=WSHLA.FSC_PARTY_DIM data=party_dim_stg force;
run;

