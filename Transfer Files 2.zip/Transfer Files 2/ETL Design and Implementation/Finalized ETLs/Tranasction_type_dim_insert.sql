proc contents data = WSHLA.FSC_TRANSACTION_TYPE_DIM;
quit;


proc sql;
    insert into WSHLA.FSC_TRANSACTION_TYPE_DIM 
        (transaction_type_key, funds_securities_code, funds_securities_desc,
         transaction_cdi_code, transaction_cdi_desc,
         trancode)
    values 
        (8989,'F', 'FUNDS', 'C', 'CREDIT','898989');
quit;


proc sql;
    insert into WSHLA.FSC_TRANSACTION_TYPE_DIM 
        (transaction_type_key, funds_securities_code, funds_securities_desc,
         transaction_cdi_code, transaction_cdi_desc,
         trancode)
    values 
        (9898,'F', 'FUNDS', 'D', 'DEBIT','989898');
quit;