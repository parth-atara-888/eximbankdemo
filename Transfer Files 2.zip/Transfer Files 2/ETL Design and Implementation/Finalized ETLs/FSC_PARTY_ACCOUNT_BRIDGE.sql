/*Party Account bridge Load Job*/


/* Step 1: FSC_PARTY_ACCOUNT_BRIDGE – Deduplicate by party_number + account_number */
PROC SORT DATA=tm_transactions(KEEP=party_number account_number
                               WHERE=(party_number is not null and account_number is not null))
          OUT=party_account_bridge_valid NODUPKEY;
  BY party_number account_number;

%LET start_time = %SYSFUNC(DATETIME(), DATETIME.); /* Record job start timestamp */

/* Count staging records for audit logging */
PROC SQL;
    SELECT COUNT(*) INTO: valid_count
    FROM WORK.party_account_bridge_valid;
QUIT;


/* Add digest and SCD fields to staging data */
DATA party_account_bridge_stg;
    SET WORK.party_account_bridge_valid; /* Load staging data */

    /* Assign change begin date */
    change_begin_date = DATETIME();
    change_end_date    = dhms('01Jun5999'd, 0, 0, 0);
    change_current_ind = 'Y'; /* Active flag */

    
    role_key = 1; 
	role_desc = "PRIMARY OWNER";

    FORMAT change_begin_date DATETIME27.6;
	FORMAT create_dttm DATETIME27.6;
    FORMAT change_end_date DATETIME27.6;
    FORMAT change_current_ind $2.;
    FORMAT role_desc $50.; 
	FORMAT role_key Z2.; 
RUN;

proc sql;
update WSHLA.FSC_PARTY_ACCOUNT_BRIDGE as bridge
set 
    CHANGE_CURRENT_IND = 'N',
    CHANGE_END_DATE = DATETIME()
where exists (
    select 1 
    from party_account_bridge_stg as stg
    where 
        bridge.account_number = stg.account_number 
        and bridge.party_number = stg.party_number
);
quit;


proc append base=WSHLA.FSC_PARTY_ACCOUNT_BRIDGE data=party_account_bridge_stg force;
run;

