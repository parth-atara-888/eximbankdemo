/*Transaction Dim Load Job*/


/* Step 1: FSC_TRANSACTION_DIM – No Deduplication, Direct Extract */
DATA transaction_dim_valid;
  SET tm_transactions;
  WHERE transaction_reference_number is not null;
  KEEP transaction_dttm transaction_reference_number transaction_description;
RUN;

/* Step 2: FSC_CASH_FLOW_FACT – On	e-to-One with TRANSACTION_REFERENCE_NUMBER */
DATA fsc_cash_flow_fact_valid;
  SET tm_transactions;
  WHERE transaction_reference_number is not null;
  transaction_currency_code = currency_code;
  KEEP transaction_dttm transaction_reference_number transaction_cdi_code transaction_currency_code
       currency_amount  status_desc secondary_account_number account_number;
RUN;

%LET start_time = %SYSFUNC(DATETIME(), DATETIME.); /* Record job start timestamp */

/* Count staging records for audit logging */
PROC SQL;
    SELECT COUNT(*) INTO: valid_count
    FROM WORK.transaction_dim_valid;
QUIT;


/*------------------------------------------
Get the Maximum Key Data
 *------------------------------------------*/
/* Generate the maximum key */
		%let etls_maxkey = -1;
%put etls_maxkey : &etls_maxkey.;

proc sql noprint;
	select compress(put(max(transaction_key), best32.)) into :etls_maxkey from 
		WSHLA.FSC_TRANSACTION_DIM;
quit;

%put etls_maxkey : &etls_maxkey.;


/* Step 3: Populate FSC_TRANSACTION_DIM */
DATA transaction_dim_stg;
    SET WORK.transaction_dim_valid; /* Load staging data */

    /* Assign surrogate key */
    transaction_key = &etls_maxkey + _N_; /* Ensure &etls_maxkey is defined as numeric */

    FORMAT transaction_key Z13.; 
RUN;

proc append base=WSHLA.FSC_TRANSACTION_DIM data=transaction_dim_stg force;
run;


/* Cleaned Final ETL Step - Cash Flow Fact Load with Required Keys */

/* Create view for lookup */
proc sql;
    create view etls_account_lookup as
    select account_key, account_number
    from core.fsc_account_dim
    where change_current_ind = 'Y';
    
    create view etls_party_lookup as
    select party_key, party_number
    from core.fsc_party_dim
    where change_current_ind = 'Y';
    
    create view etls_ext_party_lookup as
    select ext_party_account_key, external_party_number
    from core.fsc_ext_party_account_dim
    where change_current_ind = 'Y';
quit;

/* Prepare final data with key lookups using hash */
data work.cash_flow_fact_stg;
    set work.fsc_cash_flow_fact_valid;

    /* Assign surrogate key */
    transaction_key = &etls_maxkey + _N_;
    if transaction_cdi_code = 'C' then transaction_type_key = 8989;
    else if transaction_cdi_code = 'D' then transaction_type_key = 9898;

    if status_desc = 'SUCCESS' then transaction_status_key = 1;
    else transaction_status_key = 2;

    branch_key = 897568;
    posted_dttm = datetime();
    aml_analysis_date = datepart(transaction_dttm);

    /* Define hash tables */
    if _n_ = 1 then do;
        declare hash h_account(dataset:"etls_account_lookup");
        h_account.defineKey("account_number");
        h_account.defineData("account_key");
        h_account.defineDone();

        declare hash h_party(dataset:"etls_party_lookup");
        h_party.defineKey("party_number");
        h_party.defineData("party_key");
        h_party.defineDone();

        declare hash h_ext_party(dataset:"etls_ext_party_lookup");
        h_ext_party.defineKey("external_party_number");
        h_ext_party.defineData("ext_party_account_key");
        h_ext_party.defineDone();

        call missing(account_key, executing_party_key, remitter_ext_party_key, secondary_account_key);
    end;

    /* Lookup Keys */
    h_party.find(key:executing_party_number);
    executing_party_key = party_key;

    h_ext_party.find(key:remitter_ext_party_number);
    remitter_ext_party_key = ext_party_account_key;

    h_account.find(key:secondary_account_number);
    secondary_account_key = account_key;

    /* Keep only final required variables */
    keep transaction_key transaction_dttm transaction_reference_number 
         transaction_currency_code currency_amount transaction_type_key transaction_status_key
         account_number secondary_account_number branch_key posted_dttm aml_analysis_date
         executing_party_key remitter_ext_party_key secondary_account_key;
run;

/* Append to target fact table */
proc append base=WSHLA.FSC_CASH_FLOW_FACT data=work.cash_flow_fact_stg force;
run;
























