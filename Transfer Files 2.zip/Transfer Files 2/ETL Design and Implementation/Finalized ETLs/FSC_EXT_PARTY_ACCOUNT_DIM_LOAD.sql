/*Ext-Party Dim Load Job*/


/* Step 1: FSC_EXT_PARTY_ACCOUNT_DIM – Deduplicate by external_party_number + account_number */
DATA temp_ext_party;
  SET tm_transactions;
  WHERE remitter_ext_party_number is not null and ext_account_number is not null;
  external_party_number = remitter_ext_party_number;
  account_number = ext_account_number;
  KEEP external_party_number account_number ext_party_type_desc ext_party_full_name
       ext_address_line_1_text ext_address_line_2_text ext_city_name ext_state_name country_code;
RUN;

PROC SORT DATA=temp_ext_party OUT=ext_party_account_dim_valid NODUPKEY;
  BY external_party_number account_number;
RUN;

%LET start_time = %SYSFUNC(DATETIME(), DATETIME.); /* Record job start timestamp */

/* Count staging records for audit logging */
PROC SQL;
    SELECT COUNT(*) INTO: valid_count
    FROM WORK.ext_party_account_dim_valid;
QUIT;


/*------------------------------------------
Get the Maximum Key Data
 *------------------------------------------*/
/* Generate the maximum key */
		%let etls_maxkey = -1;
%put etls_maxkey : &etls_maxkey.;

proc sql noprint;
	select compress(put(max(ext_party_account_key), best32.)) into :etls_maxkey from 
		WSHLA.FSC_EXT_PARTY_ACCOUNT_DIM;
quit;

%put etls_maxkey : &etls_maxkey.;


/* Add digest and SCD fields to staging data */
DATA ext_party_account_dim_stg;
    SET WORK.ext_party_account_dim_valid; /* Load staging data */

    /* Assign change begin date */
    change_begin_date = DATETIME();
    change_end_date    = dhms('01Jun5999'd, 0, 0, 0);
    change_current_ind = 'Y'; /* Active flag */

    /* Assign surrogate key */
    ext_party_account_key = &etls_maxkey + _N_; /* Ensure &etls_maxkey is defined as numeric */
	ext_party_account_comp_key = catx(' - ', external_party_number, account_number);
	version = 1;
	create_dttm = DATETIME();

    FORMAT change_begin_date DATETIME27.6;
	FORMAT create_dttm DATETIME27.6;
    FORMAT change_end_date DATETIME27.6;
    FORMAT change_current_ind $2.;
    FORMAT ext_party_account_key Z13.; 
	FORMAT version Z2.; 
	FORMAT ext_party_account_comp_key $200.;
RUN;



proc sql;
update WSHLA.FSC_EXT_PARTY_ACCOUNT_DIM
set CHANGE_CURRENT_IND = 'N',
CHANGE_END_DATE = DATETIME()
where 
ext_party_account_comp_key in (select distinct ext_party_account_comp_key from ext_party_account_dim_stg);
quit;

proc append base=WSHLA.FSC_EXT_PARTY_ACCOUNT_DIM data=ext_party_account_dim_stg force;
run;

