from name_matching_model import ml_model_apply,filterresult,preprocessing,filterresult2
from name_matching_model import infWeight,resource_loader
import pandas as pd
import timeit

def rescore2(features,score,featureName="levenshtein_dist"):
        index=0
        reScalingFeature=features[featureName]
        ngramFeature=features["ngram_simi"]
        for i in range(len(reScalingFeature)):
            if ngramFeature[i]>=.9:
                score[i]=ngramFeature[i]
            if ngramFeature[i]<=.85and score[i]>.9:
                score[i]=ngramFeature[i]
            if reScalingFeature[i]==0:
                score[i]=1
        return score

def rescore(features,score,featureName="levenshtein_dist"):
        index=0
        reScalingFeature=features[featureName]
        ngramFeature=features["ngram_simi"]
        
        for i in range(len(reScalingFeature)):
            # if ngramFeature[i]>=.92:
            #     score[i]=ngramFeature[i]
            if reScalingFeature[i]==0:
                score[i]=1
            #score[i]=round(score[i]*100, 0)
        return score
def rescore3(features,score,newScore,featureName="levenshtein_dist"):
        index=0
        reScalingFeature=features[featureName]
        ngramFeature=features["ngram_simi"]
        
        for i in range(len(reScalingFeature)):
            # if ngramFeature[i]>=.92:
            #     score[i]=ngramFeature[i]
            if reScalingFeature[i]==0:
                score[i]=1
            if score[i]<.93:
                score[i]=newScore[i]
            #score[i]=round(score[i]*100, 0)
        return score


infWeight.loadResource()
resource_loader.load()

filepath=r"C:\effiya\root\web\apps\namescreening_ai\result\uae_test3.xlsx"
df=pd.read_excel(filepath)
featuresList=[]
total=len(df.index)
totalTime=0
for i,row in df.iterrows(): 
    t1=timeit.default_timer()
    name,_,_=preprocessing.preprocess(str(row["Imputed Name"]))
    matchedn,_,_=preprocessing.preprocess(str(row["Name"]))
    matched=[matchedn]
    score,features=ml_model_apply.applyModel(name,matched)
    newScore=filterresult2.filter_result(name,matched,score)
    score1=rescore(features,score)
    features["FullName"]=[name]
    features["MatchedName"]=[matched]
    features["new-score"]=list(map(lambda x:round(x*100, 0),score1))
    score2=rescore3(features,score,newScore)
    features["modified-score"]=list(map(lambda x:round(x*100, 0),score2))
    featuresList.append(features.iloc[0])
    t2=timeit.default_timer();
    totalTime+=t2-t1
    avgTime=totalTime/(i+1)
    print("progress: {:.3}% | expected time: {:.2} secs | doc no. {} \r".format(((i+1)/total)*100,avgTime*(total-i-1),i),end="")

pd.DataFrame(featuresList).to_excel(r"C:\effiya\root\web\apps\namescreening_ai\result\uae_test3_result.xlsx")

