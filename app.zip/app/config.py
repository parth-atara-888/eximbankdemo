#app setting
MAX_WORKERS=10
SERVER_PORT=8067

#resources
MODEL_NAME="stacked_model_15_may_2023.pickle"
#MODEL_NAME="stacked_model_25_feb_2023_2.pickle"
INF_WEIGHTS_FILENAME="infweights.xlsx"
TITLES_FILENAME=r"resources/titles.xlsx"
ORG_STD_FILENAME=r"resources/OrganizationStandardization_v2.xlsx"


#solr config
SOLR_SEARCH_ENGINE_URL="http://localhost:8983/solr/"
SOLR_RESULT_COUNT=1000



#root folder
import os
ROOT_FOLDER=os.path.dirname(os.path.abspath(__file__))
print(ROOT_FOLDER)