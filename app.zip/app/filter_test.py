from name_matching_model import ml_model_apply,filterresult
from name_matching_model import infWeight,resource_loader
from metaphone import doublemetaphone

infWeight.loadResource()
resource_loader.load()


name="Korea Daesong B".lower()
matchlist=["Korea Daesong Trading Company".lower(),"Korea Daesong Trading Corporation".lower()]

val=filterresult.filter_result(name,matchlist)
print(val)
val=filterresult.findoldScore(name,matchlist)
print(val)

name="Ryonha M".lower()
matchlist=list(map(lambda x:x.lower(),["Ryonha Machine Tool","Ryonha M","Ryonha Machine Tool Corporation"]))
val=filterresult.filter_result(name,matchlist)
print(val)
val=filterresult.findoldScore(name,matchlist)
print(val)

			

# name="Jamaah Islamiyah".lower()
# matchlist=list(map(lambda x:x.lower(),["JAM YAH TA AWUN AL ISLAMIA","Jam iyat Al Ta awun Al Islamiyya","Jamiat Ihia Al-Turath Al Islamiya"]))
# val=filter.filter_result(name,matchlist)
# print(val)
# val=filter.findoldScore(name,matchlist)
# print(val)
	

# name="Ajnad Misr".lower()
# matchlist=list(map(lambda x:x.lower(),["Ajnad",]))
# val=filter.filter_result(name,matchlist)
# print(val)
# val=filter.findoldScore(name,matchlist)
# print(val)





