import grpc
from concurrent import futures
import config
from name_matching_grpc import name_matching_pb2_grpc
from service import NameMatchingService
from name_matching_model import infWeight,resource_loader
def serve():
    infWeight.loadResource()
    resource_loader.load()
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=config.MAX_WORKERS))
    name_matching_pb2_grpc.add_NameMatchingServicer_to_server(
        NameMatchingService(), server
    )
    server.add_insecure_port("[::]:{}".format(config.SERVER_PORT))
    server.start()
    server.wait_for_termination()


if __name__ == "__main__":
    serve()