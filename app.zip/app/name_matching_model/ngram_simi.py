from itertools import combinations
from nltk import ngrams
from nltk import word_tokenize
import pandas as pd 
import os
# def getNgrams2(text,n=3,start=1):
#     n=n+1
#     totalgrams=set()
#     grams=[["".join(gram).strip() for gram in ngrams(name,i)] for i in range(start,n) for name in word_tokenize(text)] 
#     #print(grams)
#     grams=["".join(gram).strip() for gram in grams]
#     totalgrams=set(grams)
#     return totalgrams

def getNgrams(text,n=3,start=1):
    count=0
    ngrams=set()
    for token in text.split():
        for i in range(start,n+1):
            newGrams=set([token[j:j+i] for j in range(len(token)-i+1)])
            #print(newGrams)
            ngrams=ngrams.union(newGrams)
    #print(ngrams)
    return ngrams

# def getNgrams3(text,n=3,start=1):
#     n=n+1
#     totalgrams=set()
#     for name in word_tokenize(text):
#         for i in range(start,n):
#             grams=ngrams(name,i)
#             for gram in grams:
#                 temp="".join(gram).strip()
#                 if len(temp)>0:
#                     totalgrams.add(temp)
#     return totalgrams

def countMatcheNgram(ngram1,ngram2):
    count=0
    for gram in ngram2:
        if gram in ngram1: 
            count=count+1
    return count

def getSimilarity(name1,name2,grams=None):
    if grams:
        ngramsName2=grams
    else:
        ngramsName2=getNgrams(name2)
    ngramsName1=getNgrams(name1)
    #print(ngramsName2)
    matchedNgram=countMatcheNgram(ngramsName1,ngramsName2)
    #print(matchedNgram,len(ngramsName1),len(ngramsName2))
    a=(matchedNgram+0.001)/(len(ngramsName1)+0.001)
    b=(matchedNgram+0.001)/(len(ngramsName2)+0.001)
    return ((a+b))/2

if __name__=="__main__": 
    # name1="DENIS MAMADOU GERHARD CUSPERT".lower()
    # name2="diliph ibrahim hakkani cuspert".lower()
    name1="m".lower()
    name2="machine tool".lower()
    sc=getSimilarity(name1,name2)
    print(sc)


