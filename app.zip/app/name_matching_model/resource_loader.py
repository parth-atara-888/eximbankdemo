import  pickle

import config
import pandas as pd 
import numpy as np
from collections import OrderedDict
import timeit
from resources import resource
import os

regexTitlesHonorifics=None
companyKeywords=None
companyKeywords=None
titlesHonorificsKeywords=None
companyKeywordsWithoutVowel={}
titlesStandardizationDic={}
model=None
vowels=set(["a","e","i","o","u"])
def removeVowel(text):
    return "".join([char for char in text if char not in vowels])

def createRegexTitlesHonorifics(filename):
    df=pd.read_excel(filename)
    #title	partTitle
    #print(df)
    titles=[tag.lower().strip() for tag in df["title"].dropna()]
    titlesSTD=[tag.lower().strip() for tag in df["titleSTD"].dropna()]
    titlesPart=[tag.lower().strip() for tag in df["partTitle"].dropna()]
    titlesPartSTD=[tag.lower().strip() for tag in df["partTitleSTD"].dropna()]

    for keyword,std in zip(titles,titlesSTD):
        titlesStandardizationDic[" "+keyword+" "]=std
    for keyword,std in zip(titlesPart,titlesPartSTD):
        titlesStandardizationDic[" "+keyword]=std
    regex=" | ".join(titles)
    regexPart="| ".join(titlesPart)
    regex=" "+regex+" | "+regexPart
    resource.titlesStandardizationDic=titlesStandardizationDic
    return regex,set(titles+titlesPart)

def createStandardizationDic(filname):
    t1=timeit.default_timer()
    standardDic=OrderedDict()
    df=pd.read_excel(filname)
    companyKeywordsSet=set()
    for _,row in df.iterrows():
        #print(row)
        standardDic[row["Data"].lower().strip()]=row["Standard"].lower().strip()
        companyKeywordsSet.add(row["Data"].lower().strip())
        companyKeywordsSet.add(row["Standard"].lower().strip())
        companyKeywordsWithoutVowel[removeVowel(row["Data"].lower().strip())]=row["Data"].lower().strip()
        companyKeywordsWithoutVowel[removeVowel(row["Standard"].lower().strip())]=row["Data"].lower().strip()
    t2=timeit.default_timer()
    resource.companyKeywordsWithoutVowel=companyKeywordsWithoutVowel
    print("Standard Resources v1 Loaded from disk- ","Time: ",t2-t1)
    return standardDic,companyKeywordsSet



#print(regexTitlesHonorifics)


def load():
    rootFolder=config.ROOT_FOLDER
    titlesFilename=os.path.join(rootFolder,config.TITLES_FILENAME)
    orgFilename=os.path.join(rootFolder,config.ORG_STD_FILENAME)
    regexTitlesHonorifics,titlesHonorificsKeywords=(createRegexTitlesHonorifics(titlesFilename))
    resource.regexTitlesHonorifics=regexTitlesHonorifics
    resource.titlesHonorificsKeywords=titlesHonorificsKeywords
    companyStandardizationDic,companyKeywords=createStandardizationDic(orgFilename)
    resource.companyStandardizationDic=companyStandardizationDic
    resource.companyKeywords=companyKeywords
    resource.model= pickle.load(open(os.path.join(rootFolder,"model/"+config.MODEL_NAME),"rb"))