class resource:
    regexTitlesHonorifics=None
    companyKeywords=None
    companyKeywords=None
    titlesHonorificsKeywords=None
    companyKeywordsWithoutVowel=None
    titlesStandardizationDic=None
    model=None
    infFeatureDic=None
    wordVectorizer=None
