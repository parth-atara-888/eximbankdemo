import re
from resources import resource


vowels=set(["a","e","i","o","u"])

def transliterate(text):
    return text

def removeSpecialSymbol(text):
    text=re.sub(r"[^a-zA-Z(){}\[\]\- ]",'',text)
    text=re.sub(r"[^a-zA-Z ]",' ',text)
    return (re.sub(r" +",' ',text)).strip()

def removeVowel(text):
    return "".join([char for char in text if char not in vowels])


def standardizeName(text):
    tokens=text.split(" ")
    processedTokens=[tokens[0]]
    companyFlag=0
    tokens.pop(0)
    for token in tokens:
        word=removeVowel(token)
        if len(word)>2 and word in resource.companyKeywordsWithoutVowel:
            processedTokens.append(resource.companyStandardizationDic[resource.companyKeywordsWithoutVowel[word]])
            companyFlag=1
        else:
            if token in resource.companyStandardizationDic:
                token=resource.companyStandardizationDic[token]
                companyFlag=1
            processedTokens.append(token)
    return " ".join(processedTokens),companyFlag

def removeTitles(text):
    text=" "+text.lower()+" "
    standardDic=resource.titlesStandardizationDic
    matchObj=[]
    for data,standard in standardDic.items():
        textLen=len(text)
        text,count=re.subn(data, standard, text)
        if count>0:
            matchObj.append(data)
    return text.strip(),matchObj

def removeDuplicateChar(inputText):
    tokens=inputText.split()
    processedTokens=[]
    for text in tokens:
        i=1
        textSize=len(text)
        firstChar=text[0]
        while i<textSize and firstChar==text[i] and (firstChar not in vowels):
            i+=1
        text=text[i-1:].strip()
        textSize=len(text)
        j=textSize-1
        lastChar=text[j]
        while j>0 and (j-1)<textSize and lastChar==text[j-1]:
            j-=1
        text=text[:j+1].strip()
        processedTokens.append(text)
    return re.sub(r" +",' '," ".join(processedTokens)).strip()

def removeDuplicateWords(text):
    tokens=text.split()
    visitedWords=set()
    uniqueTokens=[]
    for token in tokens:
        if token not in uniqueTokens:
            uniqueTokens.append(token)
    utext=" ".join(uniqueTokens)
    return utext.strip()

def removeContentInParethesis(text):
    text1=re.sub("[\(\[].*?[\)\]]", "",text)
    if text1!=None and len(text1)>0:
        text2=removeSpecialSymbol(text1)
        if len(text2)<=1:
            return text
    if text1==None:
        return text
    if text1!=None and len(text1)<=1:
        return text
    return text1

def merge_AL_tokens(string):
    # Split the string into a list of tokens
    tokens = string.split()
    i=0
    # Iterate over the tokens and check if the current token is "AL"
    while i<(len(tokens)-1):
        if tokens[i] == "al":
            # Merge the current token with the next token
            tokens[i] += tokens[i+1]
            # Delete the next token from the list
            del tokens[i+1]
        i+=1

    # Join the updated list of tokens back into a string
    updated_string = ' '.join(tokens)
    
    return updated_string

def preprocess(text):
    text=str(text).lower()
    #transliterate
    text=transliterate(text)
    
    #removeContentInParethesis
    text=removeContentInParethesis(text)

    #remove honorofics
    text,matchObj=removeTitles(text)
    
    #spelling correction of org word,identify company name,standardize company name
    text,companyFlag=standardizeName(text)
    
    #removal special characters
    text=removeSpecialSymbol(text)
    text=merge_AL_tokens(text)
    #remove duplicates word
    text=removeDuplicateWords(text)

    #remove duplicate char from beggining
    text=removeDuplicateChar(text)
    return text,companyFlag,matchObj



if __name__ == '__main__':
    text="mr.rravi avi avi hello vvikram rravi rr c hulin  jiang"
    print(preprocess(text))

