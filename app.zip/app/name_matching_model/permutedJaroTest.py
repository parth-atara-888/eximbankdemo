import lzma
import  timeit
lzma_filters = my_filters = [
    {
      "id": lzma.FILTER_LZMA2 , 
      "preset":0,
      "lc":0,
      "lp": 0,
      "pb": 0, # assume ascii
      "mode": lzma.MODE_FAST ,
      "nice_len": 4,
      "mf": lzma.MF_BT2
    }
]
def Z(contents):
    return len(lzma.compress(contents, format=lzma.FORMAT_RAW, filters= lzma_filters))
      
def ncd(a,b):
    a=bytes(a,"utf-8")
    b=bytes(b,"utf-8")
    Za = Z(a)
    Zb = Z(b)
    Zab = Z(a+b)
    return (Zab - min(Za, Zb)) / max(Za, Zb)
t1=timeit.default_timer()

a,b="osama ladeb bin","osama laden bun"
# ba=bytes(a,"utf-8")
# Za = Z(ba)
dis=[ncd(*i) for i in  [[a,b]]*1000]
t2=timeit.default_timer()
print("ncd"," time:",t2-t1)
print(dis[0])



from itertools import permutations
from jellyfish import jaro_winkler

from abydos.distance import NCDarith

ob=NCDarith()
print("q:",ob.dist(a,b))
import textdistance
print("p:",textdistance.arith_ncd(a,b))

# def concatwords(words):
#     if len(words)>=5:
#         word1=words[0:4]
#         word2=words[4:]
#         txt=" ".join(word2)
#         lst=[]
#         lst=lst+word1
#         lst.append(txt)
#         words=lst
#     return words
# def permuted_jaro_winkler_simi(text1,text2,val=None,grams=None):
#     words2=text2.split(" ")
#     words2=concatwords(words2)
#     maxScore=0
#     p2=[p for p in permutations(words2)]
#     print(p2)
#     for perm2 in p2:
#         text2=" ".join(perm2)
#         score=jaro_winkler(text1,text2)
#         maxScore=max(maxScore,score)
#     #val=nameWordINFStat(text2)
#     factor=val if val>0 else 1

# permuted_jaro_winkler_simi("osama bin ladeb","osama laden bun",val=1)
# import lzma

# compressor = lzma.LZMACompressor()
# a="osama bin ladeb"
# print(len(a))
# t = compressor.compress(bytes(a,"utf-8"))
# print((t),len(t))
# compressor = lzma.LZMACompressor()
# a=b"osama bin ladeb"
# t = compressor.compress(a)
# print((t),len(t))