import pandas as pd
import os
from collections import defaultdict
import numpy as np
import config
import pickle
from resources import resource

VOWELS=set("aeiouAEIOU")
infFeatureDic=None
wordVectorizer=None
def removeVowels(text):
    txt="".join([char for char in str(text) if char not in VOWELS])
    return txt

def createINFDicandArray(words,infs):
    inf_list=[]
    word_dic=defaultdict(lambda : None)
    for i,(word,inf )in enumerate(zip(words,infs)):
        inf_list.append(inf)
        word_dic[word]=i
    return inf_list,word_dic

def loadResource():
    global infFeatureDic,wordVectorizer
    rootFolder=config.ROOT_FOLDER
    filepath=os.path.join(rootFolder,"resources")
    filename=config.INF_WEIGHTS_FILENAME
    infFeatureDic={}
    sheetsName=["nysiis_ngram","nysiis_word","metaphone_ngram","metaphone_word","name_word","name_ngram"]
    for sheetname in sheetsName:
        df=pd.read_excel(os.path.join(filepath,filename),sheet_name=sheetname)
        if sheetname=="name_word":
            inf_list,word_dic=createINFDicandArray(df["word"],df["normal_inf"])
        else:
            inf_list,word_dic=createINFDicandArray(df["word"],df["inf"])
        infFeatureDic[sheetname+"_word_dic"]=word_dic
        infFeatureDic[sheetname+"_inf_list"]=inf_list
        #if sheetname=="name_word":
    resource.infFeatureDic=infFeatureDic
    print("word vector loaded")
    resource.wordVectorizer=pickle.load(open(filepath+"/namevectorizer.pickle","rb"))





