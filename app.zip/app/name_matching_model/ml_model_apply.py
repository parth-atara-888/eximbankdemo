import resource_loader
from feature_generation_parallel import getFeatures as getFeaturesParallel
from feature_generation import getFeatures,getFeatures2
from resources import resource


def applyModel(name,matchList):
    model=resource.model
    probs=[]
    features=getFeatures(name,matchList)
    probs=model.predict_proba(features)[...,1]
    return probs,features

def applyModel2(namelist,matchList):
    model=resource.model
    probs=[]
    features=getFeatures2(namelist,matchList)
    probs=model.predict_proba(features)[...,1]
    return probs,features






