from ngram_simi import getNgrams
from similarity_inf_weighted import levenshtein_dist,ngram_simi,normalized_comp_dist,sorted_jaro_winkler_simi,permuted_jaro_winkler_simi,nysiisSimi,doubleMetaphoneSimi,uniqueCharCount,directMatchNamePart

from similarity_inf_weighted import uniqueCharCount,checkNonLatin,nameWordINFStat,Z,concatwordsPermutedWords

import pandas as pd

from preprocessing import preprocess
import concurrent.futures
import timeit
from jellyfish import nysiis,metaphone,hamming_distance,jaro_winkler
from metaphone import doublemetaphone
import re

def wordCountDiff(text1,text2,val=None,grams=None,comLenght=None,concatenatedwords=None,doubleMetaphoneEncode=None,nysiisEncode=None):
    n1_tokens=len(text1.split())
    n2_tokens=len(text2.split())
    return (n2_tokens-n1_tokens)

def avgFeature(df):
    features=["ngram_simi",	"sorted_jaro_winkler_simi",	"permuted_jaro_winkler_simi",	"nysiisSimi",	"doubleMetaphoneSimi"]
    df["avg_feature"]=df[features].sum(axis=1)/len(features)
    return df

def firstcharMatch(text1,text2,val=None,grams=None,comLenght=None,concatenatedwords=None,doubleMetaphoneEncode=None,nysiisEncode=None):
    text1=" ".join(list(map(lambda x:doublemetaphone(x)[0] ,text1.split())))
    text1=(re.sub(r" +",' ',text1)).strip()
    text2=(re.sub(r" +",' ',doubleMetaphoneEncode)).strip()
    text1FirstChar=set([token[0] for token in text1.split(" ") if len(token)>0])
    text2FirstChar=set([token[0] for token in text2.split(" ") if len(token)>0])
    commonfirstchar=text1FirstChar & text2FirstChar
    totalTokens=len(text1FirstChar)+len(text2FirstChar)
    return len(commonfirstchar)/totalTokens

def createFeatureSet(methods,actualList,name):
    scoreDic={}
    inp,compFlag2,_=preprocess(name)
    inpNameFeatureDic={}
    infStat=nameWordINFStat(inp)
    inpGrams=getNgrams(inp)
    bytesA=bytes(inp,"utf-8")
    Za=Z(bytesA)
    words2=inp.split(" ")
    concatenatedWordPerms=[" ".join(tup) for tup in concatwordsPermutedWords(words2)]
    nysiisEncode=" ".join(list(map(nysiis,words2)))
    doubleMetaphoneEncode=" ".join(list(map(lambda x:doublemetaphone(x)[0] ,words2)))
    for smethod in [uniqueCharCount,checkNonLatin,nameWordINFStat]:
        inpNameFeatureDic[smethod.__name__]=smethod(inp)
    methodScores={method.__name__:[] for method in methods}
    methodScoreNames1={smethod.__name__+"1":[] for smethod in [uniqueCharCount,checkNonLatin]}
    methodScoreNames2={smethod.__name__+"2":[] for smethod in [uniqueCharCount,checkNonLatin]}
    scoreDic={"companyFlagInp1":[],"companyFlagInp2":[],**methodScores,**methodScoreNames1,**methodScoreNames2}
    #actualListPreprocessed=[preprocess(actual) for actual in actualList]
    for actual in actualList:
        actual,compFlag1,_=preprocess(actual)
        scoreDic["companyFlagInp1"].append(compFlag1)
        scoreDic["companyFlagInp2"].append(compFlag2)
        for method in methods:
            score=method(actual,inp,val=infStat,grams=inpGrams,comLenght=Za,concatenatedwords=concatenatedWordPerms,nysiisEncode=nysiisEncode,doubleMetaphoneEncode=doubleMetaphoneEncode)
            scoreDic[method.__name__].append(score)
        for smethod in [uniqueCharCount,checkNonLatin]:
            scoreDic[smethod.__name__+"1"].append(smethod(actual))
            scoreDic[smethod.__name__+"2"].append(inpNameFeatureDic[smethod.__name__])
    return scoreDic


def getFeatures(name,matchList):
    methods=[levenshtein_dist,ngram_simi,normalized_comp_dist,sorted_jaro_winkler_simi,permuted_jaro_winkler_simi,nysiisSimi,doubleMetaphoneSimi,directMatchNamePart,wordCountDiff,firstcharMatch]
    t1=timeit.default_timer()
    scoreDic=createFeatureSet(methods,matchList,name)
    t2=timeit.default_timer()
    #print("feature generation time without parallel: ",t2-t1)
    featuresOrder=["companyFlagInp1","companyFlagInp2"	,"levenshtein_dist"	,"ngram_simi"	,"normalized_comp_dist"	,"sorted_jaro_winkler_simi",	"permuted_jaro_winkler_simi",	"nysiisSimi",	"doubleMetaphoneSimi"	,"uniqueCharCount1"	,"uniqueCharCount2",	"checkNonLatin1",	"checkNonLatin2","wordCountDiff","firstcharMatch","avg_feature","directMatchNamePart"]
    f_df=pd.DataFrame(scoreDic)
    f_df=avgFeature(f_df)
    f_df=f_df[featuresOrder]
    return f_df


def getinp(inp):
    inpNameFeatureDic={}
    infStat=nameWordINFStat(inp)
    inpGrams=getNgrams(inp)
    bytesA=bytes(inp,"utf-8")
    Za=Z(bytesA)
    words2=inp.split(" ")
    concatenatedWordPerms=[" ".join(tup) for tup in concatwordsPermutedWords(words2)]
    nysiisEncode=" ".join(list(map(nysiis,words2)))
    doubleMetaphoneEncode=" ".join(list(map(lambda x:doublemetaphone(x)[0] ,words2)))
    for smethod in [uniqueCharCount,checkNonLatin,nameWordINFStat]:
        inpNameFeatureDic[smethod.__name__]=smethod(inp)
    return infStat,inpGrams,Za,words2,concatenatedWordPerms,nysiisEncode,doubleMetaphoneEncode,inpNameFeatureDic



def createFeatureSet2(methods,actualList,namelist):
    methodScores={method.__name__:[] for method in methods}
    methodScoreNames1={smethod.__name__+"1":[] for smethod in [uniqueCharCount,checkNonLatin]}
    methodScoreNames2={smethod.__name__+"2":[] for smethod in [uniqueCharCount,checkNonLatin]}
    scoreDic={"companyFlagInp1":[],"companyFlagInp2":[],**methodScores,**methodScoreNames1,**methodScoreNames2}
    #actualListPreprocessed=[preprocess(actual) for actual in actualList]
    for actual,name in zip(actualList,namelist):
        infStat,inpGrams,Za,words2,concatenatedWordPerms,nysiisEncode,doubleMetaphoneEncode,inpNameFeatureDic=getinp(name)
        actual,compFlag1,_=preprocess(actual)
        scoreDic["companyFlagInp1"].append(compFlag1)
        inp,compFlag2,_=preprocess(name)
        scoreDic["companyFlagInp2"].append(compFlag2)
        for method in methods:
            score=method(actual,inp,val=infStat,grams=inpGrams,comLenght=Za,concatenatedwords=concatenatedWordPerms,nysiisEncode=nysiisEncode,doubleMetaphoneEncode=doubleMetaphoneEncode)
            scoreDic[method.__name__].append(score)
        for smethod in [uniqueCharCount,checkNonLatin]:
            scoreDic[smethod.__name__+"1"].append(smethod(actual))
            scoreDic[smethod.__name__+"2"].append(inpNameFeatureDic[smethod.__name__])
    return scoreDic


def getFeatures2(names,matchList):
    methods=[levenshtein_dist,ngram_simi,normalized_comp_dist,sorted_jaro_winkler_simi,permuted_jaro_winkler_simi,nysiisSimi,doubleMetaphoneSimi,directMatchNamePart,wordCountDiff,firstcharMatch]
    t1=timeit.default_timer()
    scoreDic=createFeatureSet2(methods,matchList,names)
    t2=timeit.default_timer()
    #print("feature generation time without parallel: ",t2-t1)
    featuresOrder=["companyFlagInp1","companyFlagInp2"	,"levenshtein_dist"	,"ngram_simi"	,"normalized_comp_dist"	,"sorted_jaro_winkler_simi",	"permuted_jaro_winkler_simi",	"nysiisSimi",	"doubleMetaphoneSimi"	,"uniqueCharCount1"	,"uniqueCharCount2",	"checkNonLatin1",	"checkNonLatin2","wordCountDiff","firstcharMatch","avg_feature","directMatchNamePart"]
    f_df=pd.DataFrame(scoreDic)
    f_df=avgFeature(f_df)
    f_df=f_df[featuresOrder]
    return f_df



