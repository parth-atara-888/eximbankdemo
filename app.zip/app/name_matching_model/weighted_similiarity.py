import infWeight 
from collections import Counter
from nltk import ngrams
from nltk import word_tokenize
import pandas as pd 
import os
import numpy as np
from scipy.sparse import  csr_matrix
from jellyfish import metaphone, nysiis
from sklearn.metrics.pairwise import cosine_similarity
from resources import resource

def getNgrams(text,n=3,start=1):
    n=n+1
    totalgrams=list()
    for name in word_tokenize(text):
        for i in range(start,n):
            grams=ngrams(name,i)
            for gram in grams:
                temp="".join(gram).strip()
                if len(temp)>0:
                    totalgrams.append(temp)
    return totalgrams

VOWELS=set("aeiouAEIOU")
def removeVowels(text):
    txt="".join([char for char in str(text) if char not in VOWELS])
    return txt

# def getWordVector(name,featureName):
#     ngrams=name.split()
#     cntObj=Counter(ngrams)
#     infList=infFeatureDic[featureName+"_inf_list"]
#     wordDict=infFeatureDic[featureName+"_word_dic"]
#     infListLen=len(infList)
#     vector=[0]*infListLen
#     # for word,count in cntObj.items():
#     #     idx=wordDict[removeVowels(word)]
#     #     if idx:
#     #         weight=infList[idx]
#     #         vector[idx]=weight*np.log(count+1)
#     return csr_matrix(vector)


def getWordVector(name,featureName):
    name=removeVowels(name)
    return resource.wordVectorizer.transform([name])
    #return csr_matrix(vector)


def getNgramVector(name,featureName):
    ngrams=getNgrams(name,n=3,start=2)
    cntObj=Counter(ngrams)
    infList=resource.infFeatureDic[featureName+"_inf_list"]
    wordDict=resource.infFeatureDic[featureName+"_word_dic"]
    infListLen=len(infList)
    vector=[0]*infListLen
    for word,count in cntObj.items():
        idx=wordDict[word]
        if idx:
            weight=infList[idx]
            vector[idx]=weight*np.log(count+1)
    return csr_matrix(vector)

def getNameNgramVector(name):
    return getNgramVector(name.lower(),"name_ngram")

def getNameWordVector(name):
    return getWordVector(name.lower(),"name_word")

def getMetaphoneNgramVector(name):
    name=" ".join(list(map(metaphone,name.split())))
    return getNgramVector(name.lower(),"metaphone_ngram")

def getMetaphoneWordVector(name):
    name=" ".join(list(map(metaphone,name.split())))
    return getWordVector(name.lower(),"metaphone_word")

def getNysiisNgramVector(name):
    name=" ".join(list(map(nysiis,name.split())))
    return getNgramVector(name.lower(),"nysiis_ngram")

def getNysiisWordVector(name):
    name=" ".join(list(map(nysiis,name.split())))
    return getWordVector(name.lower(),"nysiis_word")

def infSimilarity(vector1,vector2):
    return cosine_similarity(vector1,vector2)


def nysiisWordVectorScore(name1,name2,vector=None):
    v1=getNysiisWordVector(name1)
    v2=getNysiisWordVector(name2)
    return infSimilarity(v1,v2)[0][0]

def nysiisNgramVectorScore(name1,name2,vector=None):
    v1=getNysiisNgramVector(name1)
    v2=getNysiisNgramVector(name2)
    return infSimilarity(v1,v2)[0][0]

def metaphoneWordVectorScore(name1,name2,vector=None):
    v1=getMetaphoneWordVector(name1)
    v2=getMetaphoneWordVector(name2)
    return infSimilarity(v1,v2)[0][0]

def metaphoneNgramVectorScore(name1,name2,vector=None):
    v1=getMetaphoneNgramVector(name1)
    v2=getMetaphoneNgramVector(name2)
    return infSimilarity(v1,v2)[0][0]

def nameWordVectorScore(name1,name2,vector=None):
    v1=getNameWordVector(name1)
    v2=getNameWordVector(name2)
    return infSimilarity(v1,v2)[0][0]

def nameNgramVectorScore(name1,name2,vector=None):
    v1=getNameNgramVector(name1)
    v2=getNameNgramVector(name2)
    return infSimilarity(v1,v2)[0][0]


# print(nysiisWordVectorScore("Ravee saruj","Ravi saroj"))

# v1=getMetaphoneNgramVector("Ravee saruj")
# v2=getMetaphoneNgramVector("Ravi saroj")
# print(infSimilarity(v1,v2))

# v1=getMetaphoneWordVector("Ravee saruj")
# v2=getMetaphoneWordVector("Ravi saroj")
# print(infSimilarity(v1,v2))

# v1=getNysiisNgramVector("Ravee saruj")
# v2=getNysiisNgramVector("Ravi saroj")
# print(infSimilarity(v1,v2))

# v1=getNysiisWordVector("Ravee saruj")
# v2=getNysiisWordVector("Ravi saroj")
# print(infSimilarity(v1,v2))

# v1=getNameWordVector("MOHAMMED ABDUL QADER ABDULLA")
# v2=getNameWordVector("abdul mohammed")
# print(infSimilarity(v1,v2))

# v1=getNameNgramVector("MOHAMMED ABDUL QADER ABDULLA")
# v2=getNameNgramVector("abdul mohammed ")
# print(infSimilarity(v1,v2))

# names=[("MOHAMMED ABDUL QADER ABDULLAH","abu mohammed al qatari"),("MUHAMMED RANA","mohammad"),("ABDUL RAHMAN MOHAMED HAMED AL HINAI","abdul rehman")]
# methods=[nameNgramVectorScore,nameWordVectorScore,metaphoneNgramVectorScore,metaphoneWordVectorScore,nysiisNgramVectorScore,nysiisWordVectorScore]

# for name in names:
#     for method in methods:
#         score=method(*name)
#         print(method.__name__,": ",name,": score: ",score)

