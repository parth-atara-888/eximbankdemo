from resources import resource
from metaphone import doublemetaphone
from similarity_inf_weighted import ngram_simi
import numpy as np
import ml_model_apply
from preprocessing import preprocess
def get_token_weights(tokens):
    weight_feature="name_word"
    infFeatureDic=resource.infFeatureDic
    word_dic=infFeatureDic[weight_feature+"_word_dic"]
    inf_list=infFeatureDic[weight_feature+"_inf_list"]
    inf_val_list=[]
    for token in tokens:
        if len(token)>1:
            tokenindex=word_dic.get(token,-1)
            if tokenindex>=0:
                inf_val_list.append(inf_list[tokenindex])
            else:
                inf_val_list.append(1)
        else:
            inf_val_list.append(0.5)
    if len(inf_val_list)<1:
        inf_val_list.append(0.5)
    return inf_val_list



def find_comman_word(tokens1set,tokens2,encoding_func=None):
    encoded_words=[w for w in (map(encoding_func,tokens2))]
    words={}
    comman_words1=set()
    comman_words2=set()
    u_words1=list()
    for idx,word in enumerate(encoded_words):
        wordsidx=words.get(word,[])
        wordsidx.append(idx)
        words[word]=wordsidx
    for idx,word1 in enumerate(tokens1set):
        if word1 in words:
            comman_words1.add(idx)
            comman_words2.update(words[word1])
        else:
            u_words1.append(idx)
    return u_words1,comman_words1,comman_words2

def findoldScore(name,matchList):
    scorelist=[]
    for mname in matchList:
        score=ngram_simi(name,mname)
        scorelist.append(score)
    return scorelist


def filter_result2(name,matchList):
    encoding_func=lambda x:doublemetaphone(x)[0]
    ename=[w for w in (map(encoding_func,name.split()))]
    namet=name.split()
    scorelist=[]

    for mname in matchList:
        val=mname.split()
        u_words1,comman1,common2=find_comman_word(ename,val,encoding_func=encoding_func)
        u_words2=[i for i in range(len(val)) if i not in common2]
        u_tokens1=[namet[i] for i in u_words1]
        u_tokens2=[val[i] for i in u_words2]
        c_tokens1=[namet[i] for i in comman1]
        c_tokens2=[val[i] for i in common2]
        weights1=get_token_weights(c_tokens1)
        weights2=get_token_weights(u_tokens1)
        weights3=get_token_weights(u_tokens2)
        weight2u=1
        weight3u=1
        if len(u_tokens1)>0:
            weight2u=np.average(sorted(weights2),weights=list(range(1,len(weights2)+1)))
            print("unique weights",u_tokens1,weight2u)
        if len(u_tokens2)>0:
            weight3u=np.average(sorted(weights3),weights=list(range(1,len(weights3)+1)))
            print("unique weights",u_tokens2,weight3u)
        weightu=(weight2u+weight3u)/2
        scoreu=ngram_simi(" ".join(u_tokens1)," ".join(u_tokens2))
        if len(c_tokens1)>0:
            weight=np.average(sorted(weights1),weights=list(range(1,len(weights1)+1)))
            scorec=ngram_simi(" ".join(c_tokens1)," ".join(c_tokens2))
            scr=(scoreu*(weightu)+scorec*(weight))/(weightu+weight)
            print(name,mname,u_tokens1,u_tokens2,c_tokens1,c_tokens2,scoreu,scorec,weight,weights1)
        else:
            scr=scoreu
            print(name,mname,scoreu,"no comman")
        
        scorelist.append(scr)
    return scorelist


def filter_result(name,matchList,scoreList,inf_threshold=0.6):
    encoding_func=lambda x:doublemetaphone(x)[0]
    ename=[w for w in (map(encoding_func,name.split()))]
    name,_,_=preprocess(name)
    namet=name.split()
    new_scorelist=[]
    new_inp_list=[]
    new_match_list=[]
    weight_list=[]
    for scr,mname in  zip(scoreList,matchList):
        mname,_,_=preprocess(mname)
        val=mname.split()
        inp_weights=get_token_weights(namet)
        m_weights=get_token_weights(val)
        newthresold1=inf_threshold
        newthresold2=inf_threshold
        inp_weights_max=max(inp_weights)
        m_weights_max=max(m_weights)
        if inp_weights_max<inf_threshold:
            newthresold1=inp_weights_max-0.1
        if m_weights_max<inf_threshold:
            newthresold2=m_weights_max-0.1
        inp_f=[w for w,s in zip(namet,inp_weights) if s>newthresold1]
        mname_f=[w for w,s in zip(val,m_weights) if s>newthresold2]
        inp_f=" ".join(inp_f)
        mname_f=" ".join(mname_f)
        new_inp_list.append(inp_f)
        new_match_list.append(mname_f)
        weight=np.average(sorted(m_weights),weights=list(range(1,len(m_weights)+1)))
        weight_list.append(weight)
    #print(new_match_list,weight_list)
    scores,features=ml_model_apply.applyModel2(new_inp_list,new_match_list)
    for scr,score,weight in zip(scoreList,scores,weight_list):
        finalscore=score*(1-weight)+scr*(weight)
        new_scorelist.append(finalscore)
    return new_scorelist

        




