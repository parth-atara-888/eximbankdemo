from ngram_simi import getNgrams
from similarity_inf_weighted import levenshtein_dist,ngram_simi,normalized_comp_dist,sorted_jaro_winkler_simi,permuted_jaro_winkler_simi,nysiisSimi,doubleMetaphoneSimi,uniqueCharCount

from similarity_inf_weighted import uniqueCharCount,checkNonLatin,nameWordINFStat,Z

import pandas as pd

from preprocessing import preprocess
import concurrent.futures
import timeit






def createFeatureSet(methods,actualList,name):
    inp,compFlag2,_=preprocess(name)
    inpNameFeatureDic={}
    infStat=nameWordINFStat(inp)
    inpGrams=getNgrams(inp)
    bytesA=bytes(inp,"utf-8")
    Za=Z(bytesA)
    words2=inp.split(" ")
    concatenatedWordPerms=[" ".join(tup) for tup in concatwordsPermutedWords(words2)]
    methodScores={method.__name__:[] for method in methods}
    methodScoreNames1={smethod.__name__+"1":[] for smethod in [uniqueCharCount,checkNonLatin]}
    methodScoreNames2={smethod.__name__+"2":[] for smethod in [uniqueCharCount,checkNonLatin]}
    scoreDic={"companyFlagInp1":[],"companyFlagInp2":[],**methodScores,**methodScoreNames1,**methodScoreNames2}

    for smethod in [uniqueCharCount,checkNonLatin]:
        inpNameFeatureDic[smethod.__name__]=smethod(inp)
    actualListPreprocessed=[preprocess(actual) for actual in actualList]
    t1=timeit.default_timer()
    with concurrent.futures.ThreadPoolExecutor() as executor:
        overAllFutureList=[]
        for actual in actualListPreprocessed:
            futureDic={}
            actual,compFlag1,_=actual
            futureDic["companyFlagInp1"]=compFlag1,False
            futureDic["companyFlagInp2"]=compFlag2,False
            for method in methods:
                futureDic[method.__name__]=executor.submit(method, actual,inp,val=infStat,grams=inpGrams,comLenght=Za,concatenatedwords=concatenatedWordPerms),True
            for smethod in [uniqueCharCount,checkNonLatin]:
                futureDic[smethod.__name__+"1"]=executor.submit(smethod,actual),True
                futureDic[smethod.__name__+"2"]=inpNameFeatureDic[smethod.__name__],False
            overAllFutureList.append(futureDic)
        t2=timeit.default_timer()
        print("multiprocess Start generation time: ",t2-t1)
        for futureDic in overAllFutureList:
            for key,val in futureDic.items():
                if val[1]:
                    value=val[0].result()
                else:
                    value=val[0]
                scoreDic[key].append(value)
    t3=timeit.default_timer()
    print("multiprocess completed generation time: ",t3-t2)

    return scoreDic


def getFeatures(name,matchList):
    methods=[levenshtein_dist,ngram_simi,normalized_comp_dist,sorted_jaro_winkler_simi,permuted_jaro_winkler_simi,nysiisSimi,doubleMetaphoneSimi]
    t1=timeit.default_timer()
    scoreDic=createFeatureSet(methods,matchList,name)
    t2=timeit.default_timer()
    print("feature generation time: ",t2-t1)
    return pd.DataFrame(scoreDic)



