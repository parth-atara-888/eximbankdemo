
from Levenshtein import distance,jaro_winkler
from nltk import jaccard_distance
from dice_coefficient import dice_coefficient
from ngram_simi import getSimilarity,getNgrams
from jellyfish import nysiis,metaphone,hamming_distance,jaro_winkler
from metaphone import doublemetaphone
from itertools import permutations
from fuzzywuzzy.fuzz import ratio
import string
from weighted_similiarity import getNameWordVector
import numpy as np
import math
import lzma
import timeit

lzma_filters = my_filters = [
    {
      "id": lzma.FILTER_LZMA2 , 
      "preset":0,
      "lc":0,
      "lp": 0,
      "pb": 0, # assume ascii
      "mode": lzma.MODE_FAST ,
      "nice_len": 4,
      "mf": lzma.MF_BT2
    }
]
def Z(contents):
    return len(lzma.compress(contents, format=lzma.FORMAT_RAW, filters= lzma_filters))
      
def ncd(a,b,comLenght):
    a=bytes(a,"utf-8")
    b=bytes(b,"utf-8")
    #Za = Z(a)
    Za=  Z(a)
    Zb =comLenght
    Zab = Z(a+b)
    return (Zab - min(Za, Zb)) / max(Za, Zb)



# a.Phonetics
# i.Phonix (can exclude soundex and phonex)
# ii.NYSIIS
# iii.Double Metaphone
# iv.Fuzzy soundex

# b.Pattern matching
# i.Damerau-Levenshtein Distance
# ii.Jaccard similarity
# iii.Dice coefficient
# iv.N-gram
# v.Normalized compression distance
# vi.Sorted Winkler
# vii.Permuted Winkler

# c.Combined technique
# i.       Syllable alignment pattern searching



#Pattern matching
def levenshtein_dist(text1,text2,val=None,grams=None,comLenght=None,concatenatedwords=None,doubleMetaphoneEncode=None,nysiisEncode=None):
    return distance(text1,text2)

def jaccard_dist(text1,text2,val=None,grams=None,comLenght=None,concatenatedwords=None,doubleMetaphoneEncode=None,nysiisEncode=None):
    if grams:
        inpGrams=grams
    else:
        inpGrams=getNgrams(text2)
    return jaccard_distance(getNgrams(text1),inpGrams)

def dice_coeff(text1,text2,val=None,grams=None,comLenght=None,concatenatedwords=None,doubleMetaphoneEncode=None,nysiisEncode=None):
    return dice_coefficient(text1,text2)

def ngram_simi(text1,text2,val=1,grams=None,comLenght=None,concatenatedwords=None,doubleMetaphoneEncode=None,nysiisEncode=None):
    #print("ngrma,",val)
    #val=nameWordINFStat(text2)
    factor=val if val>0 else 1
    if grams:
        return getSimilarity(text1,text2,grams=grams)*factor
    return getSimilarity(text1,text2)*factor

def normalized_comp_dist(text1,text2,val=None,grams=None,comLenght=None,concatenatedwords=None,doubleMetaphoneEncode=None,nysiisEncode=None):
    return ncd(text1,text2,comLenght)

def jaro_winkler_simi(text1,text2,val=None,grams=None,comLenght=None,concatenatedwords=None,doubleMetaphoneEncode=None,nysiisEncode=None):
    #val=nameWordINFStat(text2)
    factor=val if val>0 else 1
    return jaro_winkler(text1,text2)*factor

def sorted_jaro_winkler_simi(text1,text2,val=None,grams=None,comLenght=None,concatenatedwords=None,doubleMetaphoneEncode=None,nysiisEncode=None):
    text1=" ".join(sorted(text1.split(" ")))
    text2=" ".join(sorted(text2.split(" ")))
    #val=nameWordINFStat(text2)
    factor=val if val>0 else 1
    return jaro_winkler(text1,text2)*factor

def concatwordsPermutedWords(words,concatN=3):
    if len(words)>concatN:
        word1=words[0:concatN-1]
        word2=words[concatN-1:]
        txt=" ".join(word2)
        lst=[]
        lst=lst+word1
        lst.append(txt)
        words=lst
    permutedWords=[p for p in permutations(words)]
    return permutedWords


def permuted_jaro_winkler_simi(text1,text2,val=None,grams=None,comLenght=None,concatenatedwords=None,doubleMetaphoneEncode=None,nysiisEncode=None):
    scores=[jaro_winkler(text1,perm2) for perm2 in concatenatedwords]
    maxScore=max(scores)
    factor=val if val>0 else 1
    return maxScore*factor

def nysiisSimi(text1,text2,val=None,grams=None,comLenght=None,concatenatedwords=None,doubleMetaphoneEncode=None,nysiisEncode=None):
    text1=" ".join(list(map(nysiis,text1.split())))
    text2=nysiisEncode
    factor=val if val>0 else 1
    return ngram_simi(text1,text2,val)*factor


def doubleMetaphoneSimi(text1,text2,val=None,grams=None,comLenght=None,concatenatedwords=None,doubleMetaphoneEncode=None,nysiisEncode=None):
    text1=" ".join(list(map(lambda x:doublemetaphone(x)[0] ,text1.split())))
    text2=doubleMetaphoneEncode
    #val=nameWordINFStat(text2)
    factor=val if val>0 else 1
    return ngram_simi(text1,text2,val)*factor

def uniqueCharCount(text):
    return len(set(text))


def countSimilarWords(text1,text2,val=None,grams=None,comLenght=None,concatenatedwords=None,doubleMetaphoneEncode=None,nysiisEncode=None):
    tokens1=text1.split()
    tokens2=text2.split()
    matchCount=0
    for token1 in tokens1:
        for token2 in tokens2:
            score=ratio(token1,token2)
            if score>=90:
                matchCount+=1
    count=min([len(tokens1),len(tokens2),matchCount])
    return count

def checkNonLatin(text):
    mytable = text.maketrans(string.punctuation,"0"*len(string.punctuation)) 
    return 1 if text.translate(mytable).isalnum() else 0




def nameWordINFStat(text):
    # vector=getNameWordVector(text)
    # #print(vector.data)
    # print(list(vector.data))
    # val=np.median(list(vector.data))
    # return 0 if math.isnan(val) else val
    return 1

def directMatchNamePart(text1,text2,val=None,grams=None,comLenght=None,concatenatedwords=None,doubleMetaphoneEncode=None,nysiisEncode=None):
    name1tokens=set(text1.split(" "))
    name2tokens=set(text2.split(" "))
    commanTokens=name1tokens.intersection(name2tokens)
    commanTokensCount=len(commanTokens)
    totalTokens=len(name1tokens)+len(name2tokens)
    return commanTokensCount/totalTokens







    




















