
from Levenshtein import distance,jaro_winkler
from nltk import jaccard_distance
from dice_coefficient import dice_coefficient
from ngram_simi import getSimilarity,getNgrams
import textdistance
from jellyfish import jaro_winkler,nysiis,metaphone,hamming_distance
from metaphone import doublemetaphone
from itertools import permutations
from fuzzywuzzy.fuzz import ratio
import string
from weighted_similiarity import getNameWordVector
import numpy as np
import math





# a.Phonetics
# i.Phonix (can exclude soundex and phonex)
# ii.NYSIIS
# iii.Double Metaphone
# iv.Fuzzy soundex

# b.Pattern matching
# i.Damerau-Levenshtein Distance
# ii.Jaccard similarity
# iii.Dice coefficient
# iv.N-gram
# v.Normalized compression distance
# vi.Sorted Winkler
# vii.Permuted Winkler

# c.Combined technique
# i.       Syllable alignment pattern searching



#Pattern matching
def levenshtein_dist(text1,text2):
    return distance(text1,text2)

def jaccard_dist(text1,text2):
    return jaccard_distance(getNgrams(text1),getNgrams(text2))

def dice_coeff(text1,text2):
    return dice_coefficient(text1,text2)

def ngram_simi(text1,text2):
    return getSimilarity(text1,text2)

def normalized_comp_dist(text1,text2):
    return textdistance.arith_ncd(text1,text2)

def jaro_winkler_simi(text1,text2):
    return jaro_winkler(text1,text2)

def sorted_jaro_winkler_simi(text1,text2):
    text1=" ".join(sorted(text1.split(" ")))
    text2=" ".join(sorted(text2.split(" ")))
    return jaro_winkler(text1,text2)

def concatwords(words):
    if len(words)>=5:
        word1=words[0:4]
        word2=words[4:]
        txt=" ".join(word2)
        lst=[]
        lst=lst+word1
        lst.append(txt)
        words=lst
    return words


def permuted_jaro_winkler_simi(text1,text2):
    words1=text1.split(" ")
    words2=text2.split(" ")
    words1=concatwords(words1)
    words2=concatwords(words2)
    maxScore=0
    p1=[p for p in permutations(words1)]
    p2=[p for p in permutations(words2)]
    for perm in p1:
        text1=" ".join(perm)
        for perm2 in p2:
            text2=" ".join(perm2)
            score=jaro_winkler(text1,text2)
            maxScore=max(maxScore,score)
    return maxScore

def nysiisSimi(text1,text2):
    text1=" ".join(list(map(nysiis,text1.split())))
    text2=" ".join(list(map(nysiis,text2.split())))
    return ngram_simi(text1,text2)


def doubleMetaphoneSimi(text1,text2):
    text1=" ".join(list(map(lambda x:doublemetaphone(x)[0] ,text1.split())))
    text2=" ".join(list(map(lambda x:doublemetaphone(x)[0] ,text2.split())))
    return ngram_simi(text1,text2)

def uniqueCharCount(text):
    return len(set(text))


def countSimilarWords(text1,text2):
    tokens1=text1.split()
    tokens2=text2.split()
    matchCount=0
    for token1 in tokens1:
        for token2 in tokens2:
            score=ratio(token1,token2)
            if score>=90:
                matchCount+=1
    count=min([len(tokens1),len(tokens2),matchCount])
    return count

def checkNonLatin(text):
    mytable = text.maketrans(string.punctuation,"0"*len(string.punctuation)) 
    return 1 if text.translate(mytable).isalnum() else 0




def nameWordINFStat(text):
    vector=getNameWordVector(text)
    #print(vector.data)
    val=np.median(list(vector.data))
    
    return 0 if math.isnan(val) else val









    




















