from name_matching_grpc import name_matching_pb2_grpc
from name_matching_model import ml_model_apply,filterresult,filterresult2
from solr_search_engine.solr_client import solrRequest
from name_matching_grpc.name_matching_pb2 import (
    NameMatchingResponse,
    NameMatchingDetail,
    NameMatchingRequest,
    NameMatchingScoreResponse
)
import grpc
import traceback
import heapq
# repeated string candidateNames=1;
#     string names=1;
#     int32 threshold=2;
#     int32 top=3;


class NameMatchingService(name_matching_pb2_grpc.NameMatchingServicer):
    def nameMatch(self, request, context):
        try:
            name=request.name
            threshold= request.threshold
            top= request.top
            matchList=request.candidateNames
            print(matchList)
            #name="osama bin"
            solrResult=solrRequest(name)
            #matchList=[res["ENTITY_NAME"][0] for res in solrResult]
            score,features=ml_model_apply.applyModel(name,matchList)
            threshold=threshold/100
            score=self.rescore(features,score)
            results=[NameMatchingDetail(name=match,score=score) for score,match in zip(score,matchList)]
            sortedList=heapq.nlargest(top,results,key=lambda x: x.score)
        except Exception as e:
            traceback.print_exc()
            raise e 
        return NameMatchingResponse(nameMatchingDetail=sortedList)
    
    def nameMatchScore(self, request, context):
        try:
            name=request.name
            matchList=request.candidateNames
            #print(matchList)
            #name="osama bin"
            #matchList=[res["ENTITY_NAME"][0] for res in solrResult]
            score,features=ml_model_apply.applyModel(name,matchList)
            #print("***",score)
            newScore=filterresult2.filter_result(name,matchList,score)
            #print("###",newScore)
            score2=self.rescore3(features,score,newScore)
            #score2=self.rescore(features,score)
            #print("&&&",score2)
            score2=[round(scr*100, 0) for scr in score2]
            #print("%%% ",score2)
        except Exception as e:
            traceback.print_exc()
            raise e 
        return NameMatchingScoreResponse(scores=score2)

    def rescore(self,features,score,featureName="levenshtein_dist"):
        index=0
        reScalingFeature=features[featureName]
        ngramFeature=features["ngram_simi"]
        for i in range(len(reScalingFeature)):
            # if ngramFeature[i]>=.9 and ngramFeature[i]!=1:
            #     score[i]=ngramFeature[i]
            if reScalingFeature[i]==0:
                score[i]=1
            #score[i]=round(score[i]*100, 0)
        return score
    
    def rescore3(self,features,score,newScore,featureName="levenshtein_dist"):
        index=0
        reScalingFeature=features[featureName]
        ngramFeature=features["ngram_simi"]
        
        for i in range(len(reScalingFeature)):
            # if ngramFeature[i]>=.92:
            #     score[i]=ngramFeature[i]
            if reScalingFeature[i]==0:
                score[i]=1
            if score[i]<.93:
                score[i]=newScore[i]
            #score[i]=round(score[i]*100, 0)
        return score


if __name__=="__main__":
    obj=NameMatchingService()
    obj.NameMatch(None,None)