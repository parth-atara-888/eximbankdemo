import grpc
from name_matching_grpc import name_matching_pb2_grpc,name_matching_pb2
import  timeit

def run():
    channel = grpc.insecure_channel('localhost:5000')
    stub = name_matching_pb2_grpc.NameMatchingStub(channel)
    req=name_matching_pb2.NameMatchingRequest(name='osama bin laden',top=10,threshold=70,c)
    print(req)
    t1=timeit.default_timer()
    response = stub.nameMatch(req)
    t2=timeit.default_timer()
    print("Name client received: " , response)
    print("searchTime: ",t2-t1)

run()