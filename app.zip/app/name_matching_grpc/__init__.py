import sys
import os
dir_name=os.path.dirname(__file__)
sys.path.insert(0,dir_name)
# os.environ["GRPC_VERBOSITY"]="DEBUG"
# os.environ["GRPC_TRACE"]="http"
#GRPC_TRACE=http
#GRPC_VERBOSITY=DEBUG