import win32serviceutil
import win32service
import win32event
import servicemanager
import socket

from multiprocessing import Process
from server import serve


class AppServerSvc (win32serviceutil.ServiceFramework):
    _svc_name_ = "effiya-name-search-ai"
    _svc_display_name_ = "Effiya Search-ai"
    _svc_description_ = "Effiya name-search-ai service at port 8967"

    def __init__(self, *args):
        super().__init__(*args)

    def SvcStop(self):
        self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING)
        self.process.terminate()
        self.ReportServiceStatus(win32service.SERVICE_STOPPED)

    def SvcDoRun(self):
        self.process = Process(target=self.main)
        self.process.start()
        self.process.run()

    def main(self):
        serve()

if __name__ == '__main__':
    win32serviceutil.HandleCommandLine(AppServerSvc)