import pysolr
import config

SOLR_URL=config.SOLR_SEARCH_ENGINE_URL
RESULT_COUNT=config.SOLR_RESULT_COUNT
solr = pysolr.Solr(SOLR_URL+'EntityNgramMatch/')

def solrRequest(name):
    results = solr.search('ENTITY_NAME:({})'.format(name),fl="*,score",rows=RESULT_COUNT)
    docs=results.docs
    #print(docs)
    return docs

