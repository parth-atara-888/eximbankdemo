-- Table: core.fsc_branch_dim

-- DROP TABLE IF EXISTS core.fsc_branch_dim;

CREATE TABLE IF NOT EXISTS core.fsc_branch_dim
(
    branch_key numeric(12,0) NOT NULL,
    branch_type_desc character varying(10) COLLATE pg_catalog."default",
    branch_number character varying(40) COLLATE pg_catalog."default",
    branch_name character varying(100) COLLATE pg_catalog."default",
    branch_status_desc character varying(35) COLLATE pg_catalog."default",
    bank_number character varying(25) COLLATE pg_catalog."default",
    street_address_1 character varying(40) COLLATE pg_catalog."default",
    street_address_2 character varying(40) COLLATE pg_catalog."default",
    street_city_name character varying(35) COLLATE pg_catalog."default",
    street_state_code character varying(3) COLLATE pg_catalog."default",
    street_state_name character varying(35) COLLATE pg_catalog."default",
    street_postal_code character varying(10) COLLATE pg_catalog."default",
    street_country_code character(2) COLLATE pg_catalog."default",
    street_country_name character varying(100) COLLATE pg_catalog."default",
    phone_number character varying(25) COLLATE pg_catalog."default",
    change_begin_date timestamp with time zone,
    change_end_date timestamp with time zone NOT NULL,
    change_current_ind character(1) COLLATE pg_catalog."default" NOT NULL,
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT fsc_branch_dim_pkey PRIMARY KEY (branch_key)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS core.fsc_branch_dim
    OWNER to amldbadmin_123;

REVOKE ALL ON TABLE core.fsc_branch_dim FROM csscenarioadmin_emp_123;

GRANT ALL ON TABLE core.fsc_branch_dim TO amldbadmin_123;

GRANT SELECT ON TABLE core.fsc_branch_dim TO amldbuser_123;

GRANT SELECT ON TABLE core.fsc_branch_dim TO csbatch_123;

GRANT SELECT ON TABLE core.fsc_branch_dim TO csscenarioadmin_123;

GRANT SELECT ON TABLE core.fsc_branch_dim TO csscenarioadmin_emp_123;
-- Index: xie2fsc_branch_dim

-- DROP INDEX IF EXISTS core.xie2fsc_branch_dim;

CREATE INDEX IF NOT EXISTS xie2fsc_branch_dim
    ON core.fsc_branch_dim USING btree
    (branch_name COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
-- Index: xie3fsc_branch_dim

-- DROP INDEX IF EXISTS core.xie3fsc_branch_dim;

CREATE INDEX IF NOT EXISTS xie3fsc_branch_dim
    ON core.fsc_branch_dim USING btree
    (branch_number COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
	
	
	
	
	
	-- Table: core.fsc_associate_dim

-- DROP TABLE IF EXISTS core.fsc_associate_dim;

CREATE TABLE IF NOT EXISTS core.fsc_associate_dim
(
    associate_key numeric(12,0) NOT NULL,
    associate_name character varying(200) COLLATE pg_catalog."default",
    associate_number character varying(50) COLLATE pg_catalog."default",
    associate_first_name character varying(50) COLLATE pg_catalog."default",
    associate_last_name character varying(50) COLLATE pg_catalog."default",
    associate_middle_name character varying(100) COLLATE pg_catalog."default",
    associate_title_desc character varying(50) COLLATE pg_catalog."default",
    associate_status_desc character varying(35) COLLATE pg_catalog."default",
    work_phone_number character varying(25) COLLATE pg_catalog."default",
    email_address character varying(254) COLLATE pg_catalog."default",
    branch_number character varying(40) COLLATE pg_catalog."default",
    branch_name character varying(100) COLLATE pg_catalog."default",
    change_begin_date timestamp with time zone,
    change_end_date timestamp with time zone NOT NULL,
    change_current_ind character(1) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT fsc_associate_dim_pkey PRIMARY KEY (associate_key)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS core.fsc_associate_dim
    OWNER to amldbadmin_123;

REVOKE ALL ON TABLE core.fsc_associate_dim FROM csscenarioadmin_emp_123;

GRANT ALL ON TABLE core.fsc_associate_dim TO amldbadmin_123;

GRANT SELECT ON TABLE core.fsc_associate_dim TO amldbuser_123;

GRANT SELECT ON TABLE core.fsc_associate_dim TO csbatch_123;

GRANT SELECT ON TABLE core.fsc_associate_dim TO csscenarioadmin_123;

GRANT SELECT ON TABLE core.fsc_associate_dim TO csscenarioadmin_emp_123;
-- Index: xie1fsc_associate_dim

-- DROP INDEX IF EXISTS core.xie1fsc_associate_dim;

CREATE INDEX IF NOT EXISTS xie1fsc_associate_dim
    ON core.fsc_associate_dim USING btree
    (associate_number COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
-- Index: xie6fsc_associate_dim

-- DROP INDEX IF EXISTS core.xie6fsc_associate_dim;

CREATE INDEX IF NOT EXISTS xie6fsc_associate_dim
    ON core.fsc_associate_dim USING btree
    (associate_last_name COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
	
	
	
	-- Table: core.fsc_account_dim

-- DROP TABLE IF EXISTS core.fsc_account_dim;

CREATE TABLE IF NOT EXISTS core.fsc_account_dim
(
    account_key numeric(12,0) NOT NULL,
    account_number character varying(50) COLLATE pg_catalog."default" NOT NULL,
    line_of_business_name character varying(35) COLLATE pg_catalog."default",
    account_type_desc character varying(20) COLLATE pg_catalog."default" NOT NULL,
    account_currency_code character varying(3) COLLATE pg_catalog."default" NOT NULL,
    account_currency_name character varying(100) COLLATE pg_catalog."default" NOT NULL,
    account_registration_type_desc character varying(20) COLLATE pg_catalog."default",
    account_registration_name character varying(255) COLLATE pg_catalog."default",
    account_name character varying(40) COLLATE pg_catalog."default",
    alternate_name character varying(40) COLLATE pg_catalog."default",
    account_open_date timestamp with time zone,
    account_close_date timestamp with time zone,
    account_status_desc character varying(35) COLLATE pg_catalog."default",
    dormant_ind character(1) COLLATE pg_catalog."default",
    product_line_name character varying(35) COLLATE pg_catalog."default",
    product_category_name character varying(35) COLLATE pg_catalog."default",
    product_type_name character varying(35) COLLATE pg_catalog."default",
    product_name character varying(35) COLLATE pg_catalog."default",
    product_number character varying(25) COLLATE pg_catalog."default",
    account_tax_id character varying(35) COLLATE pg_catalog."default",
    account_tax_id_type_code character(1) COLLATE pg_catalog."default",
    account_tax_state_code character varying(3) COLLATE pg_catalog."default",
    account_primary_branch_name character varying(100) COLLATE pg_catalog."default",
    currency_based_account_ind character(1) COLLATE pg_catalog."default",
    maturity_date timestamp with time zone,
    original_loan_amount numeric(16,5),
    collateral_type_code character varying(10) COLLATE pg_catalog."default",
    collateral_type_desc character varying(60) COLLATE pg_catalog."default",
    insured_amount numeric(16,5),
    employee_ind character(1) COLLATE pg_catalog."default",
    letter_of_credit_onfile_ind character(1) COLLATE pg_catalog."default",
    cash_intensive_business_ind character(1) COLLATE pg_catalog."default",
    trade_finance_ind character(1) COLLATE pg_catalog."default",
    payoff_redemption_date timestamp with time zone,
    associate_number character varying(50) COLLATE pg_catalog."default",
    term numeric(4,0),
    term_code character varying(2) COLLATE pg_catalog."default",
    payment_frequency numeric(4,0),
    payment_frequency_code character varying(2) COLLATE pg_catalog."default",
    change_begin_date timestamp with time zone,
    change_end_date timestamp with time zone NOT NULL DEFAULT to_date('59990101'::text, 'YYYYMMDD'::text),
    change_current_ind character(1) COLLATE pg_catalog."default" NOT NULL,
    opened_by_party_number character varying(50) COLLATE pg_catalog."default",
    opened_by_party_name character varying(200) COLLATE pg_catalog."default",
    opened_by_party_title character varying(50) COLLATE pg_catalog."default",
    opened_by_party_type character varying(50) COLLATE pg_catalog."default",
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT fsc_account_dim_pkey PRIMARY KEY (account_key)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS core.fsc_account_dim
    OWNER to amldbadmin_123;

ALTER TABLE IF EXISTS core.fsc_account_dim
    ENABLE ROW LEVEL SECURITY;

REVOKE ALL ON TABLE core.fsc_account_dim FROM csscenarioadmin_emp_123;

GRANT ALL ON TABLE core.fsc_account_dim TO amldbadmin_123;

GRANT SELECT ON TABLE core.fsc_account_dim TO amldbuser_123;

GRANT SELECT ON TABLE core.fsc_account_dim TO csbatch_123;

GRANT SELECT ON TABLE core.fsc_account_dim TO csefiler_123;

GRANT SELECT ON TABLE core.fsc_account_dim TO csefiler_emp_123;

GRANT SELECT ON TABLE core.fsc_account_dim TO csinvestigator_123;

GRANT SELECT ON TABLE core.fsc_account_dim TO csinvestigator_emp_123;

GRANT SELECT ON TABLE core.fsc_account_dim TO csscenarioadmin_123;

GRANT SELECT ON TABLE core.fsc_account_dim TO csscenarioadmin_emp_123;
-- Index: xie1fsc_account_dim

-- DROP INDEX IF EXISTS core.xie1fsc_account_dim;

CREATE INDEX IF NOT EXISTS xie1fsc_account_dim
    ON core.fsc_account_dim USING btree
    (account_number COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
-- Index: xie2fsc_account_dim

-- DROP INDEX IF EXISTS core.xie2fsc_account_dim;

CREATE INDEX IF NOT EXISTS xie2fsc_account_dim
    ON core.fsc_account_dim USING btree
    (account_name COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
-- Index: xie3fsc_account_dim

-- DROP INDEX IF EXISTS core.xie3fsc_account_dim;

CREATE INDEX IF NOT EXISTS xie3fsc_account_dim
    ON core.fsc_account_dim USING btree
    (account_tax_id COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
-- POLICY: emp_access

-- DROP POLICY IF EXISTS emp_access ON core.fsc_account_dim;

CREATE POLICY emp_access
    ON core.fsc_account_dim
    AS PERMISSIVE
    FOR ALL
    TO public
    USING (((CURRENT_USER = ANY (ARRAY['csscenarioadmin_emp_123'::name, 'csinvestigator_emp_123'::name, 'csefiler_emp_123'::name, 'csbatch_123'::name, 'amldbadmin_123'::name, 'amldbuser_123'::name, 'csamletl_123'::name])) OR (employee_ind <> 'Y'::bpchar) OR (employee_ind IS NULL)))
    WITH CHECK (true);
	
	
	
	
	
	-- Table: core.fsc_cash_flow_fact

-- DROP TABLE IF EXISTS core.fsc_cash_flow_fact;

CREATE TABLE IF NOT EXISTS core.fsc_cash_flow_fact
(
    transaction_key numeric(12,0) NOT NULL,
    account_key numeric(12,0) NOT NULL,
    country_code character(2) COLLATE pg_catalog."default" NOT NULL,
    transaction_type_key numeric(12,0) NOT NULL,
    transaction_dttm timestamp with time zone NOT NULL,
    transaction_status_key numeric(5,0) NOT NULL,
    transaction_currency_code character varying(12) COLLATE pg_catalog."default" NOT NULL,
    branch_key numeric(12,0) NOT NULL,
    remitter_ext_party_key numeric(12,0) NOT NULL,
    beneficiary_ext_party_key numeric(12,0) NOT NULL,
    posted_dttm timestamp with time zone,
    associate_key numeric(12,0) NOT NULL,
    executing_party_key numeric(12,0) NOT NULL,
    executing_ext_party_key numeric(12,0),
    currency_amount numeric(18,5) NOT NULL,
    currency_amount_in_txn_ccy numeric(18,5) NOT NULL,
    currency_amount_in_account_ccy numeric(18,5) NOT NULL,
    secondary_account_key numeric(12,0) NOT NULL,
    related_ind character(1) COLLATE pg_catalog."default" NOT NULL DEFAULT 'U'::bpchar,
    third_party_ind character(1) COLLATE pg_catalog."default",
    CONSTRAINT fsc_cash_flow_fact_pkey PRIMARY KEY (transaction_key),
    CONSTRAINT fsc_cash_flow_fact_account_key_fkey FOREIGN KEY (account_key)
        REFERENCES core.fsc_account_dim (account_key) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fsc_cash_flow_fact_associate_key_fkey FOREIGN KEY (associate_key)
        REFERENCES core.fsc_associate_dim (associate_key) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fsc_cash_flow_fact_beneficiary_ext_party_key_fkey FOREIGN KEY (beneficiary_ext_party_key)
        REFERENCES core.fsc_ext_party_account_dim (ext_party_account_key) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fsc_cash_flow_fact_branch_key_fkey FOREIGN KEY (branch_key)
        REFERENCES core.fsc_branch_dim (branch_key) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fsc_cash_flow_fact_executing_ext_party_key_fkey FOREIGN KEY (executing_ext_party_key)
        REFERENCES core.fsc_ext_party_account_dim (ext_party_account_key) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fsc_cash_flow_fact_executing_party_key_fkey FOREIGN KEY (executing_party_key)
        REFERENCES core.fsc_party_dim (party_key) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fsc_cash_flow_fact_remitter_ext_party_key_fkey FOREIGN KEY (remitter_ext_party_key)
        REFERENCES core.fsc_ext_party_account_dim (ext_party_account_key) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fsc_cash_flow_fact_secondary_account_key_fkey FOREIGN KEY (secondary_account_key)
        REFERENCES core.fsc_account_dim (account_key) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fsc_cash_flow_fact_transaction_key_fkey FOREIGN KEY (transaction_key)
        REFERENCES core.fsc_transaction_dim (transaction_key) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fsc_cash_flow_fact_transaction_status_key_fkey FOREIGN KEY (transaction_status_key)
        REFERENCES core.fsc_transaction_status_dim (transaction_status_key) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fsc_cash_flow_fact_transaction_type_key_fkey FOREIGN KEY (transaction_type_key)
        REFERENCES core.fsc_transaction_type_dim (transaction_type_key) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS core.fsc_cash_flow_fact
    OWNER to amldbadmin_123;

REVOKE ALL ON TABLE core.fsc_cash_flow_fact FROM csscenarioadmin_emp_123;

GRANT ALL ON TABLE core.fsc_cash_flow_fact TO amldbadmin_123;

GRANT SELECT ON TABLE core.fsc_cash_flow_fact TO amldbuser_123;

GRANT SELECT ON TABLE core.fsc_cash_flow_fact TO csbatch_123;

GRANT SELECT ON TABLE core.fsc_cash_flow_fact TO csscenarioadmin_123;

GRANT SELECT ON TABLE core.fsc_cash_flow_fact TO csscenarioadmin_emp_123;
-- Index: cash_flow_secondary_idx

-- DROP INDEX IF EXISTS core.cash_flow_secondary_idx;

CREATE INDEX IF NOT EXISTS cash_flow_secondary_idx
    ON core.fsc_cash_flow_fact USING btree
    (secondary_account_key ASC NULLS LAST)
    TABLESPACE pg_default;
-- Index: xie4fsc_cash_flow_fact

-- DROP INDEX IF EXISTS core.xie4fsc_cash_flow_fact;

CREATE INDEX IF NOT EXISTS xie4fsc_cash_flow_fact
    ON core.fsc_cash_flow_fact USING btree
    (account_key ASC NULLS LAST)
    TABLESPACE pg_default;
-- Index: xif5account_credits_fact

-- DROP INDEX IF EXISTS core.xif5account_credits_fact;

CREATE INDEX IF NOT EXISTS xif5account_credits_fact
    ON core.fsc_cash_flow_fact USING btree
    (transaction_dttm ASC NULLS LAST)
    TABLESPACE pg_default;
	
	
	
	-- Table: core.fsc_party_account_bridge

-- DROP TABLE IF EXISTS core.fsc_party_account_bridge;

CREATE TABLE IF NOT EXISTS core.fsc_party_account_bridge
(
    account_number character varying(50) COLLATE pg_catalog."default" NOT NULL,
    party_number character varying(50) COLLATE pg_catalog."default" NOT NULL,
    role_key numeric(2,0) NOT NULL,
    change_begin_date timestamp with time zone NOT NULL,
    role_desc character varying(20) COLLATE pg_catalog."default",
    change_end_date timestamp with time zone NOT NULL,
    change_current_ind character(1) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT fsc_party_account_bridge_pkey PRIMARY KEY (account_number, party_number, role_key, change_begin_date)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS core.fsc_party_account_bridge
    OWNER to amldbadmin_123;

REVOKE ALL ON TABLE core.fsc_party_account_bridge FROM csscenarioadmin_emp_123;

GRANT ALL ON TABLE core.fsc_party_account_bridge TO amldbadmin_123;

GRANT SELECT ON TABLE core.fsc_party_account_bridge TO amldbuser_123;

GRANT SELECT ON TABLE core.fsc_party_account_bridge TO csbatch_123;

GRANT SELECT ON TABLE core.fsc_party_account_bridge TO csscenarioadmin_123;

GRANT SELECT ON TABLE core.fsc_party_account_bridge TO csscenarioadmin_emp_123;
-- Index: fsc_party_account_bridge_ix01

-- DROP INDEX IF EXISTS core.fsc_party_account_bridge_ix01;

CREATE INDEX IF NOT EXISTS fsc_party_account_bridge_ix01
    ON core.fsc_party_account_bridge USING btree
    (account_number COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
-- Index: xie1fsc_party_account_bridge

-- DROP INDEX IF EXISTS core.xie1fsc_party_account_bridge;

CREATE INDEX IF NOT EXISTS xie1fsc_party_account_bridge
    ON core.fsc_party_account_bridge USING btree
    (party_number COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
	
	
	
	
	-- Table: core.fsc_party_dim

-- DROP TABLE IF EXISTS core.fsc_party_dim;

CREATE TABLE IF NOT EXISTS core.fsc_party_dim
(
    party_key numeric(12,0) NOT NULL,
    party_number character varying(50) COLLATE pg_catalog."default" NOT NULL,
    party_type_desc character varying(20) COLLATE pg_catalog."default" NOT NULL,
    party_tax_id character varying(35) COLLATE pg_catalog."default",
    party_tax_id_type_code character(1) COLLATE pg_catalog."default",
    party_identification_id character varying(35) COLLATE pg_catalog."default",
    party_identification_type_desc character varying(4) COLLATE pg_catalog."default",
    party_id_state_code character varying(3) COLLATE pg_catalog."default",
    party_id_country_code character(2) COLLATE pg_catalog."default",
    party_date_of_birth date,
    party_gender character(1) COLLATE pg_catalog."default",
    party_first_name character varying(50) COLLATE pg_catalog."default",
    party_last_name character varying(50) COLLATE pg_catalog."default",
    party_middle_name character varying(100) COLLATE pg_catalog."default",
    party_name character varying(200) COLLATE pg_catalog."default",
    doing_business_as_name character varying(70) COLLATE pg_catalog."default",
    party_status_desc character varying(20) COLLATE pg_catalog."default",
    ultimate_parent_name character varying(35) COLLATE pg_catalog."default",
    residence_country_code character(2) COLLATE pg_catalog."default",
    residence_country_name character varying(100) COLLATE pg_catalog."default",
    citizenship_country_code character(2) COLLATE pg_catalog."default",
    citizenship_country_name character varying(100) COLLATE pg_catalog."default",
    org_country_of_business_code character(2) COLLATE pg_catalog."default",
    org_country_of_business_name character varying(100) COLLATE pg_catalog."default",
    employee_ind character(1) COLLATE pg_catalog."default",
    employee_number character varying(20) COLLATE pg_catalog."default",
    employer_name character varying(35) COLLATE pg_catalog."default",
    employer_phone_number character varying(25) COLLATE pg_catalog."default",
    email_address character varying(254) COLLATE pg_catalog."default",
    occupation_desc character varying(50) COLLATE pg_catalog."default",
    industry_code character varying(10) COLLATE pg_catalog."default",
    industry_code_rr character varying(10) COLLATE pg_catalog."default",
    industry_desc character varying(255) COLLATE pg_catalog."default",
    phone_number_1 character varying(25) COLLATE pg_catalog."default",
    phone_number_2 character varying(25) COLLATE pg_catalog."default",
    phone_number_3 character varying(25) COLLATE pg_catalog."default",
    annual_income_amount numeric(10,0),
    net_worth_amount numeric(10,0),
    marital_status_desc character varying(35) COLLATE pg_catalog."default",
    last_contact_date timestamp with time zone,
    politically_exposed_person_ind character(1) COLLATE pg_catalog."default",
    non_profit_org_ind character(1) COLLATE pg_catalog."default",
    customer_since_date timestamp with time zone,
    change_begin_date timestamp with time zone,
    change_end_date timestamp with time zone NOT NULL,
    change_current_ind character(1) COLLATE pg_catalog."default" NOT NULL,
    external_party_ind character(1) COLLATE pg_catalog."default",
    legal_entity_type character varying(30) COLLATE pg_catalog."default",
    money_orders_ind character(1) COLLATE pg_catalog."default",
    travelers_cheques_ind character(1) COLLATE pg_catalog."default",
    prepaid_cards_ind character(1) COLLATE pg_catalog."default",
    msb_ind character(1) COLLATE pg_catalog."default",
    money_transmitter_ind character(1) COLLATE pg_catalog."default",
    currency_exchange_ind character(1) COLLATE pg_catalog."default",
    check_casher_ind character(1) COLLATE pg_catalog."default",
    internet_gambling_ind character(1) COLLATE pg_catalog."default",
    trust_account_ind character(1) COLLATE pg_catalog."default",
    foreign_consulate_embassy_ind character(1) COLLATE pg_catalog."default",
    issues_bearer_shares_ind character(1) COLLATE pg_catalog."default",
    negative_news_ind character(1) COLLATE pg_catalog."default",
    lst_update_date timestamp with time zone,
    fico_score numeric(3,0),
    ben_own_exempt_ind character(1) COLLATE pg_catalog."default" DEFAULT 'N'::bpchar,
    insider_code character varying(1) COLLATE pg_catalog."default",
    cif_officer character varying(6) COLLATE pg_catalog."default",
    online_registration_date timestamp with time zone,
    low_risk_override_ind character(1) COLLATE pg_catalog."default" DEFAULT 'N'::bpchar,
    version integer NOT NULL DEFAULT 1,
    entity_name_individual_mc character varying(100) COLLATE pg_catalog."default",
    entity_name_organization_mc character varying(100) COLLATE pg_catalog."default",
    CONSTRAINT fsc_party_dim_pkey PRIMARY KEY (party_key)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS core.fsc_party_dim
    OWNER to amldbadmin_123;

ALTER TABLE IF EXISTS core.fsc_party_dim
    ENABLE ROW LEVEL SECURITY;

REVOKE ALL ON TABLE core.fsc_party_dim FROM csscenarioadmin_emp_123;

GRANT ALL ON TABLE core.fsc_party_dim TO amldbadmin_123;

GRANT SELECT ON TABLE core.fsc_party_dim TO amldbuser_123;

GRANT SELECT ON TABLE core.fsc_party_dim TO csbatch_123;

GRANT SELECT ON TABLE core.fsc_party_dim TO csefiler_123;

GRANT SELECT ON TABLE core.fsc_party_dim TO csefiler_emp_123;

GRANT SELECT ON TABLE core.fsc_party_dim TO csinvestigator_123;

GRANT SELECT ON TABLE core.fsc_party_dim TO csinvestigator_emp_123;

GRANT SELECT ON TABLE core.fsc_party_dim TO csscenarioadmin_123;

GRANT SELECT ON TABLE core.fsc_party_dim TO csscenarioadmin_emp_123;
-- Index: xie12fsc_party_dim

-- DROP INDEX IF EXISTS core.xie12fsc_party_dim;

CREATE INDEX IF NOT EXISTS xie12fsc_party_dim
    ON core.fsc_party_dim USING btree
    (party_name COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
-- Index: xie13fsc_party_dim

-- DROP INDEX IF EXISTS core.xie13fsc_party_dim;

CREATE INDEX IF NOT EXISTS xie13fsc_party_dim
    ON core.fsc_party_dim USING btree
    (party_number COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
-- Index: xie14fsc_party_dim

-- DROP INDEX IF EXISTS core.xie14fsc_party_dim;

CREATE INDEX IF NOT EXISTS xie14fsc_party_dim
    ON core.fsc_party_dim USING btree
    (party_tax_id COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
-- Index: xie17fsc_party_dim

-- DROP INDEX IF EXISTS core.xie17fsc_party_dim;

CREATE INDEX IF NOT EXISTS xie17fsc_party_dim
    ON core.fsc_party_dim USING btree
    (phone_number_1 COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
-- Index: xie18fsc_party_dim

-- DROP INDEX IF EXISTS core.xie18fsc_party_dim;

CREATE INDEX IF NOT EXISTS xie18fsc_party_dim
    ON core.fsc_party_dim USING btree
    (phone_number_2 COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
-- Index: xie19fsc_party_dim

-- DROP INDEX IF EXISTS core.xie19fsc_party_dim;

CREATE INDEX IF NOT EXISTS xie19fsc_party_dim
    ON core.fsc_party_dim USING btree
    (phone_number_3 COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
-- Index: xie20fsc_party_dim

-- DROP INDEX IF EXISTS core.xie20fsc_party_dim;

CREATE INDEX IF NOT EXISTS xie20fsc_party_dim
    ON core.fsc_party_dim USING btree
    (employer_name COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
-- Index: xie23fsc_party_dim

-- DROP INDEX IF EXISTS core.xie23fsc_party_dim;

CREATE INDEX IF NOT EXISTS xie23fsc_party_dim
    ON core.fsc_party_dim USING btree
    (employer_phone_number COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
-- Index: xie7fsc_party_dim

-- DROP INDEX IF EXISTS core.xie7fsc_party_dim;

CREATE INDEX IF NOT EXISTS xie7fsc_party_dim
    ON core.fsc_party_dim USING btree
    (party_last_name COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
-- POLICY: emp_access

-- DROP POLICY IF EXISTS emp_access ON core.fsc_party_dim;

CREATE POLICY emp_access
    ON core.fsc_party_dim
    AS PERMISSIVE
    FOR ALL
    TO public
    USING (((CURRENT_USER = ANY (ARRAY['csscenarioadmin_emp_123'::name, 'csinvestigator_emp_123'::name, 'csefiler_emp_123'::name, 'csbatch_123'::name, 'amldbadmin_123'::name, 'amldbuser_123'::name, 'csamletl_123'::name])) OR (employee_ind <> 'Y'::bpchar) OR (employee_ind IS NULL)))
    WITH CHECK (true);
	
	
	
	
	-- Table: core.fsc_transaction_dim

-- DROP TABLE IF EXISTS core.fsc_transaction_dim;

CREATE TABLE IF NOT EXISTS core.fsc_transaction_dim
(
    transaction_key numeric(12,0) NOT NULL,
    transaction_dttm timestamp with time zone NOT NULL,
    transaction_reference_number character varying(256) COLLATE pg_catalog."default" NOT NULL,
    transaction_description character varying(255) COLLATE pg_catalog."default",
    security_name character varying(35) COLLATE pg_catalog."default",
    deal_number character varying(35) COLLATE pg_catalog."default",
    check_number character varying(10) COLLATE pg_catalog."default",
    mechanism_id character varying(40) COLLATE pg_catalog."default",
    image_number character varying(20) COLLATE pg_catalog."default",
    CONSTRAINT fsc_transaction_dim_pkey PRIMARY KEY (transaction_key)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS core.fsc_transaction_dim
    OWNER to amldbadmin_123;

REVOKE ALL ON TABLE core.fsc_transaction_dim FROM csscenarioadmin_emp_123;

GRANT ALL ON TABLE core.fsc_transaction_dim TO amldbadmin_123;

GRANT SELECT ON TABLE core.fsc_transaction_dim TO amldbuser_123;

GRANT SELECT ON TABLE core.fsc_transaction_dim TO csbatch_123;

GRANT SELECT ON TABLE core.fsc_transaction_dim TO csscenarioadmin_123;

GRANT SELECT ON TABLE core.fsc_transaction_dim TO csscenarioadmin_emp_123;
-- Index: xie1fsc_transaction_dim

-- DROP INDEX IF EXISTS core.xie1fsc_transaction_dim;

CREATE INDEX IF NOT EXISTS xie1fsc_transaction_dim
    ON core.fsc_transaction_dim USING btree
    (transaction_dttm ASC NULLS LAST)
    TABLESPACE pg_default;
	
	
	
	-- Table: core.fsc_account_trade_fact

-- DROP TABLE IF EXISTS core.fsc_account_trade_fact;

CREATE TABLE IF NOT EXISTS core.fsc_account_trade_fact
(
    transaction_key numeric(12,0) NOT NULL,
    account_key numeric(12,0) NOT NULL,
    branch_key numeric(12,0) NOT NULL,
    transaction_type_key numeric(12,0) NOT NULL,
    transaction_status_key numeric(5,0) NOT NULL,
    trade_dttm timestamp with time zone NOT NULL,
    executed_dttm timestamp with time zone NOT NULL,
    posted_dttm timestamp with time zone NOT NULL,
    settlement_dttm timestamp with time zone NOT NULL,
    quantity_executed numeric(15,5),
    execution_price numeric(10,5),
    transaction_currency_code character varying(12) COLLATE pg_catalog."default" NOT NULL,
    principal_amount_in_txn_ccy numeric(15,5),
    principal_amount numeric(15,5),
    principal_amount_in_acct_ccy numeric(15,5) NOT NULL,
    associate_key numeric(12,0),
    CONSTRAINT fsc_account_trade_fact_pkey PRIMARY KEY (transaction_key),
    CONSTRAINT fsc_account_trade_fact_account_key_fkey FOREIGN KEY (account_key)
        REFERENCES core.fsc_account_dim (account_key) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fsc_account_trade_fact_associate_key_fkey FOREIGN KEY (associate_key)
        REFERENCES core.fsc_associate_dim (associate_key) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fsc_account_trade_fact_branch_key_fkey FOREIGN KEY (branch_key)
        REFERENCES core.fsc_branch_dim (branch_key) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fsc_account_trade_fact_transaction_key_fkey FOREIGN KEY (transaction_key)
        REFERENCES core.fsc_transaction_dim (transaction_key) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fsc_account_trade_fact_transaction_status_key_fkey FOREIGN KEY (transaction_status_key)
        REFERENCES core.fsc_transaction_status_dim (transaction_status_key) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fsc_account_trade_fact_transaction_type_key_fkey FOREIGN KEY (transaction_type_key)
        REFERENCES core.fsc_transaction_type_dim (transaction_type_key) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS core.fsc_account_trade_fact
    OWNER to amldbadmin_123;

REVOKE ALL ON TABLE core.fsc_account_trade_fact FROM csscenarioadmin_emp_123;

GRANT ALL ON TABLE core.fsc_account_trade_fact TO amldbadmin_123;

GRANT SELECT ON TABLE core.fsc_account_trade_fact TO amldbuser_123;

GRANT SELECT ON TABLE core.fsc_account_trade_fact TO csbatch_123;

GRANT SELECT ON TABLE core.fsc_account_trade_fact TO csscenarioadmin_123;

GRANT SELECT ON TABLE core.fsc_account_trade_fact TO csscenarioadmin_emp_123;
-- Index: xie1fsc_account_trade_fact

-- DROP INDEX IF EXISTS core.xie1fsc_account_trade_fact;

CREATE INDEX IF NOT EXISTS xie1fsc_account_trade_fact
    ON core.fsc_account_trade_fact USING btree
    (trade_dttm ASC NULLS LAST)
    TABLESPACE pg_default;
-- Index: xie2fsc_account_trade_fact

-- DROP INDEX IF EXISTS core.xie2fsc_account_trade_fact;

CREATE INDEX IF NOT EXISTS xie2fsc_account_trade_fact
    ON core.fsc_account_trade_fact USING btree
    (branch_key ASC NULLS LAST)
    TABLESPACE pg_default;