/*define libname fdhdata*/
libname fdhdata postgres server='sasserver.demo.sas.com' port=5432  user='dbmsowner' password='Orion123' database=SharedServices schema = fdhdata;
/* Create temptable using passthrough as omboarding customer not accessible */

proc sql;
connect to postgres as x1 (server='sasserver.demo.sas.com' port=5432 user='dbmsowner' password='Orion123' database=SharedServices);

create table onboardingtable as 
select * from connection to x1
(
  select 
    "Onboarding_customer".*, 
    "Onboarding_customer".riskband as old_riskband, 
    "Onboarding_customer".riskscore as old_riskscore, 
    "Onboarding_customer".last_modified_date as last_review_date, 
    cast('' as varchar(100)) as new_riskband, 
    cast(null as numeric(5,2)) as new_riskscore,
    cast(null as timestamp) as review_date
  from fdhdata."Onboarding_customer"
  where riskband = 'High'
);

disconnect from x1;
quit;


/*========= create table defination of onboarded_customer ======= */

Data tempind;
set onboardingtable;
where customer_type = 'Ind';
run;

Data tempnonind;
set onboardingtable;
where customer_type = 'Cor';
run;

/* ===== define macro for ind CDD ===== */
%macro IndividualCDD(application_id,temp_doi,temp_name,temp_country);

proc sql;
select COMPRESS(Country) into: Country
from WSHLA.CountryLookup A
where A.temp_country = "&temp_country.";
quit;

data _null_;
 file req;
length request_body $2000.;
put %unquote(%nrbquote('{
	"screeningNamesListDto":[
	{
	"name": "&temp_name.",
	"dob": "&temp_doi.",
	"uniqueId": "&application_id.",
	"nationalityCountryName": "&country.",
    "matchType": "Fuzzy",
    "riskCategory": "",
    "sensitivity": "80",
    "typeDesc": "",
    "listSource": "",
    "listSubCat": "",
   	"identificationNumber": "",
    "screeningType": ""
}
]
}'));
run;


 data _null_;
	infile req;
	input;
	put _INFILE_;
run;
  
options set=SSLREQCERT="allow";
proc http in=req
 out = rsp
 headerout = rsp_o
url = 'https://demo.effiya.com/get-screening-list-with-uniqueID/'
method = 'post'
ct = 'application/json';
run;

libname myjson2 JSON fileref = rsp;

data _null_;
	infile rsp;
	input;
	put _INFILE_;
run;
  

data tempresponse;
set MYJSON2.NAMESCREENINGRESPONSE;
run;

%macro checkresponse();

proc sql;
select compress(put(min(ordinal_nameScreeningResponse),best.)) into: responsecheck
from tempresponse;
quit;

/* options notes; */
%put responsecheck: &responsecheck.;


/* %if %SYSFUNC(strip(&responsecheck.)) = 1 %then %do; */
%if %SYSEVALF(&responsecheck. =1 ) %then %do;



proc sql;
select strip(kyc_age),strip(kyc_employment),strip(kyc_annualincome),strip(kyc_maritalstatus),strip(kyc_bankrelationship),
strip(kyc_annualtxncount),strip(kyc_annualtxnvalue),strip(kyc_profession),strip(kyc_pep)
 into: age,:employment,:annualincome,:maritalstatus,:bankrelationship,:annualtxncount,:annualtxnvalue,:profession,:pep
from work.tempind
where uniqueid = &application_id.;
quit;


 %Let age = %sysfunc(Strip(&age.));
 %Let employment = %sysfunc(Strip(&employment.));
 %Let annualincome = %sysfunc(Strip(&annualincome.));
 %Let maritalstatus = %sysfunc(Strip(&maritalstatus.));
 %Let bankrelationship = %sysfunc(Strip(&bankrelationship.));
 %Let annualtxncount = %sysfunc(Strip(&annualtxncount.));
 %Let annualtxnvalue = %sysfunc(Strip(&annualtxnvalue.));
 %Let profession = %sysfunc(Strip(&profession.));
 %Let pep = %sysfunc(Strip(&pep.));


filename indrsp temp;
filename indrspo temp;
filename indreq temp;


data _null_;
file indreq;
length request_body $2000.;
put %unquote(%nrbquote('
{
	"requestID": "&application_id.",
	"customerID": "&application_id.",
	"customer_type": "individual",
	"age": "&age.",
	"employment_type": "&employment.",
	"annual_income": "&annualincome.",
	"marital_status": "&maritalstatus.",
	"bank_relationship": "&bankrelationship.",
	"annual_txn_count": "&annualtxncount.",
	"annual_txn_value":"&annualtxnvalue.",
	"nationality": "&temp_country.",
	"profession": "&profession.",
	"pep_indicator": "&pep."
}
'));
run;



 data _null_;
	infile indreq;
	input;
	put _INFILE_;
run;
  
options set=SSLREQCERT="allow";
proc http in=indreq
 out = indrsp
 headerout = indrspo
url = 'https://demo.effiya.com/kyc/api/cdd-scoring'
method = 'post'
ct = 'application/json';
run;

libname myjson3 JSON fileref = indrsp;

data _null_;
	infile indrsp;
	input;
	put _INFILE_;
run;

data tempindresponse;
set MYJSON3.data;
run;


proc sql;
select riskband, riskscore into:riskband:riskscore
from tempindresponse
quit;

proc sql;
update onboardingtable
set new_riskband = '&riskband.',
new_riskscore = &riskscore.
where uniqueid = &application_id.;
quit;

%end;
%else %do;

proc sql;
update onboardingtable
set new_riskband = 'High',
new_riskscore = 3
where uniqueid = &application_id.;
quit;

%end;


%mend;

%mend;


/* ===== define macro for Non-ind CDD ===== */
%macro NonindividualCDD(application_id,temp_doi,temp_name,temp_country);

proc sql;
select COMPRESS(Country) into: Country
from WSHLA.CountryLookup A
where A.temp_country = "&temp_country.";
quit;


data _null_;
 file req;
length request_body $2000.;
put %unquote(%nrbquote('{
	"screeningNamesListDto":[
	{
	"name": "&temp_name.",
	"dob": "&temp_doi.",
	"uniqueId": "&application_id.",
	"nationalityCountryName": "&country.",
    "matchType": "Fuzzy",
    "riskCategory": "",
    "sensitivity": "80",
    "typeDesc": "",
    "listSource": "",
    "listSubCat": "",
   	"identificationNumber": "",
    "screeningType": ""
}
]
}'));
run;


 data _null_;
	infile req;
	input;
	put _INFILE_;
run;
  
options set=SSLREQCERT="allow";
proc http in=req
 out = rsp
 headerout = rsp_o
url = 'https://demo.effiya.com/get-screening-list-with-uniqueID/'
method = 'post'
ct = 'application/json';
run;

libname myjson2 JSON fileref = rsp;

data _null_;
	infile rsp;
	input;
	put _INFILE_;
run;
  

data tempresponse;
set MYJSON2.NAMESCREENINGRESPONSE;
run;

%macro checkresponse();

proc sql;
select compress(put(min(ordinal_nameScreeningResponse),best.)) into: responsecheck
from tempresponse;
quit;

/* options notes; */
%put responsecheck: &responsecheck.;


/* %if %SYSFUNC(strip(&responsecheck.)) = 1 %then %do; */
%if %SYSEVALF(&responsecheck. =1 ) %then %do;



proc sql;
select strip(kyc_businessnature),strip(kyc_legalstatus),strip(kyc_businesstenure),strip(kyc_annualturnover),strip(kyc_bankrelationship),
strip(chief_accountant_country),strip(kyc_annualtxnvalue),strip(kyc_profession),strip(kyc_pep)
 into: businessnature,:legalstatus,:businesstenure,:annualturnover,:bankrelationship,:stakeholdernationality,:annualtxnvalue,:profession,:pep
from work.tempind
where uniqueid = &application_id.;
quit;


%Let businessnature = %sysfunc(Strip(&businessnature.));
 %Let legalstatus = %sysfunc(Strip(&legalstatus.));
 %Let businesstenure = %sysfunc(Strip(&businesstenure.));
 %Let annualturnover = %sysfunc(Strip(&annualturnover.));
 %Let bankrelationship = %sysfunc(Strip(&bankrelationship.));
 %Let stakeholdernationality = %sysfunc(Strip(&stakeholdernationality.));
 %Let annualtxnvalue = %sysfunc(Strip(&annualtxnvalue.));
 %Let profession = %sysfunc(Strip(&profession.));
 %Let pep = %sysfunc(Strip(&pep.));


filename indrsp temp;
filename indrspo temp;
filename indreq temp;


data _null_;
file indreq;
length request_body $2000.;
put %unquote(%nrbquote('
{
	"requestID": "&application_id.",
	"customerID": "&application_id.",
	"customer_type": "corporate",
	"business_nature":"&businessnature.",
	"legal_status":"&legalstatus.",
	"business_tenure":"&businesstenure.",
	"shareholder_nationality" :"&stakeholdernationality.",
	"annual_turnover":"&annualturnover.",
	"bank_relationship":"&bankrelationship.",
	"stakeholder_profession":"&profession.",
	"annual_txn_value":"&annualtxnvalue.",
	"country_of_incorporation": "&temp_country.",
	"shareholder_pep_status":"&pep."
}
'));
run;


 data _null_;
	infile indreq;
	input;
	put _INFILE_;
run;
  
options set=SSLREQCERT="allow";
proc http in=indreq
 out = indrsp
 headerout = indrspo
url = 'https://demo.effiya.com/kyc/api/cdd-scoring'
method = 'post'
ct = 'application/json';
run;

libname myjson3 JSON fileref = indrsp;

data _null_;
	infile indrsp;
	input;
	put _INFILE_;
run;

data tempindresponse;
set MYJSON3.data;
run;

proc sql;
select riskband, riskscore into:riskband:riskscore
from tempindresponse
quit;

proc sql;
update onboardingtable
set new_riskband = '&riskband.',
new_riskscore = &riskscore.
where uniqueid = &application_id.;
quit;

%end;
%else %do;

proc sql;
update onboardingtable
set new_riskband = 'High',
new_riskscore = 3
where uniqueid = &application_id.;
quit;

%end;


%mend;

%mend;



/* ===== Iterate through all of the rows in each table ======*/

/* for ind customers */

/* Iterate through rows in tempind */
data _null_;
set tempind;
call execute(cats('%nrstr(%IndividualCDD)(', id, ', ', quote(trim(doj)), ', ', quote(trim(name)), ', ', quote(trim(country)), ');'));
run;

/* Iterate through rows in tempnonind */
data _null_;
set tempnonind;
call execute(cats('%nrstr(%NonIndividualCDD)(', id, ', ', quote(trim(doj)), ', ', quote(trim(name)), ', ', quote(trim(country)), ');'));
run;

/* delete before append */

proc append base = core.onboarded_customer data = onboardingtable;
run;


/* ===== Reindex the entity to make it searchable in VI ===== */
/*Defining temporary files*/
	filename rsp temp;
	filename rsp_o temp;
	filename jsoncnt temp;
	%let server=https://sasserver.demo.sas.com;
	
data _null_;
		file jsoncnt;
		length json_content $2000.;
		put %unquote(%nrbquote('{"parameters": {"type": "SEARCH_INDEX_LOADER"},"tasks":[{"parameters": {"type":"LOAD_DOCUMENT","name":"onboarded_customer"}}]}'));
	run;

data _null_;
		infile jsoncnt;
		input;
		put _INFILE_;
	run;

	options noquotelenmax;
options set=SSLREQCERT="allow";
		proc http in=jsoncnt
		out=rsp
		headerout=rsp_o
		url="https://sasserver.demo.sas.com/svi-datahub/admin/asyncJobs?new"
		method="POST"
		OAUTH_BEARER=SAS_SERVICES
		ct="application/json"
        clear_cache;
	run;

